/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Pumping Lemma Interactive Lab & Educational Adversary Game
 */

class PumpingLemmaLab {
  constructor() {
    this.currentMode = 'regular'; // 'regular' | 'cfl'
    this.selectedLanguageId = 'anbn';
    this.p = 3;
    this.s = '000111';
    this.selectedSplitIndex = 0;
    this.validSplits = [];
    this.i = 2;

    this.regularLanguages = [
      {
        id: 'anbn',
        name: 'L = { 0ⁿ 1ⁿ | n ≥ 0 }',
        description: 'Strings of 0s followed by an equal number of 1s.',
        sampleString: (p) => '0'.repeat(p) + '1'.repeat(p),
        isInLanguage: (str) => {
          const match = str.match(/^(0*)(1*)$/);
          if (!match) return false;
          return match[1].length === match[2].length;
        },
        violationReason: (pumped) => {
          const match = pumped.match(/^(0*)(1*)$/);
          if (!match) return `"${pumped}" is not even of the form 0*1*!`;
          const num0 = match[1].length;
          const num1 = match[2].length;
          return `In "${pumped}", count of 0s is ${num0} while count of 1s is ${num1}. Since ${num0} ≠ ${num1}, the string is NOT in L!`;
        }
      },
      {
        id: 'wwr',
        name: 'L = { w wᴿ | w ∈ {0,1}* }',
        description: 'Even-length palindromes.',
        sampleString: (p) => '0'.repeat(p) + '11' + '0'.repeat(p),
        isInLanguage: (str) => {
          if (str.length % 2 !== 0) return false;
          const half = str.length / 2;
          const w = str.slice(0, half);
          const wr = str.slice(half).split('').reverse().join('');
          return w === wr;
        },
        violationReason: (pumped) => {
          return `Pumped string "${pumped}" is no longer symmetric around its center, violating the palindrome structure w wᴿ!`;
        }
      },
      {
        id: 'n_squared',
        name: 'L = { 0ⁿ² | n ≥ 0 }',
        description: 'Strings of 0s whose length is a perfect square: { ε, 0, 0000, 0⁹, 0¹⁶, ... }',
        sampleString: (p) => '0'.repeat(p * p),
        isInLanguage: (str) => {
          if (!/^0*$/.test(str)) return false;
          const len = str.length;
          const sqrt = Math.round(Math.sqrt(len));
          return sqrt * sqrt === len;
        },
        violationReason: (pumped) => {
          const len = pumped.length;
          return `Length of "${pumped}" is ${len}, which lies strictly between two consecutive squares and is NOT a perfect square!`;
        }
      },
      {
        id: 'primes',
        name: 'L = { 0ᵖ | p is prime }',
        description: 'Strings of 0s whose length is a prime number: { 00, 000, 00000, 0⁷, ... }',
        sampleString: (p) => {
          const primes = [2, 3, 5, 7, 11, 13, 17, 19, 23];
          const prime = primes.find(pr => pr >= p) || 7;
          return '0'.repeat(prime);
        },
        isInLanguage: (str) => {
          if (!/^0*$/.test(str)) return false;
          const n = str.length;
          if (n <= 1) return false;
          for (let i = 2; i <= Math.sqrt(n); i++) {
            if (n % i === 0) return false;
          }
          return true;
        },
        violationReason: (pumped) => {
          const len = pumped.length;
          return `Length of "${pumped}" is ${len}, which is composite (divisible by factor), hence NOT prime!`;
        }
      }
    ];

    this.cflLanguages = [
      {
        id: 'anbncn',
        name: 'L = { aⁿ bⁿ cⁿ | n ≥ 0 }',
        description: 'Strings with equal numbers of a\'s, b\'s, and c\'s in sequence.',
        sampleString: (p) => 'a'.repeat(p) + 'b'.repeat(p) + 'c'.repeat(p),
        isInLanguage: (str) => {
          const m = str.match(/^(a*)(b*)(c*)$/);
          if (!m) return false;
          return m[1].length === m[2].length && m[2].length === m[3].length;
        },
        violationReason: (pumped) => {
          const m = pumped.match(/^(a*)(b*)(c*)$/);
          if (!m) return `Pumped string "${pumped}" mixes symbols out of order!`;
          return `Counts in "${pumped}" are a=${m[1].length}, b=${m[2].length}, c=${m[3].length}. They are not all equal!`;
        }
      },
      {
        id: 'ww',
        name: 'L = { w w | w ∈ {a, b}* }',
        description: 'Direct repetition of the same string twice.',
        sampleString: (p) => 'a'.repeat(p) + 'b'.repeat(p) + 'a'.repeat(p) + 'b'.repeat(p),
        isInLanguage: (str) => {
          if (str.length % 2 !== 0) return false;
          const half = str.length / 2;
          return str.slice(0, half) === str.slice(half);
        },
        violationReason: (pumped) => {
          return `First half and second half of "${pumped}" do not match, violating w = w!`;
        }
      }
    ];
  }

  getCurrentLanguages() {
    return this.currentMode === 'regular' ? this.regularLanguages : this.cflLanguages;
  }

  getCurrentLanguage() {
    return this.getCurrentLanguages().find(l => l.id === this.selectedLanguageId) || this.getCurrentLanguages()[0];
  }

  // Generate all valid decompositions xyz for regular languages:
  // 1. |xy| <= p
  // 2. |y| >= 1
  generateRegularSplits(s, p) {
    const splits = [];
    const maxXY = Math.min(p, s.length);

    for (let xLen = 0; xLen < maxXY; xLen++) {
      for (let yLen = 1; xLen + yLen <= maxXY; yLen++) {
        const x = s.slice(0, xLen);
        const y = s.slice(xLen, xLen + yLen);
        const z = s.slice(xLen + yLen);

        splits.push({
          x, y, z,
          xLen, yLen, zLen: z.length,
          label: `x="${x || 'ε'}" [len ${xLen}], y="${y}" [len ${yLen}], z="${z}" [len ${z.length}]`
        });
      }
    }
    return splits;
  }

  pumpString(split, i) {
    const yPumped = split.y.repeat(i);
    return split.x + yPumped + split.z;
  }
}
