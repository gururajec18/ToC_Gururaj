/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Interactive Canvas Engine: Rendering, Drag/Drop, Transitions, High-DPI & Math
 */

class AutomataCanvas {
  constructor(canvasElement, automaton, options = {}) {
    this.canvas = canvasElement;
    this.ctx = this.canvas.getContext('2d');
    this.automaton = automaton;
    this.options = Object.assign({
      readOnly: false,
      showGrid: true,
      onStateSelect: null,
      onStateDoubleClick: null,
      onTransitionDoubleClick: null,
      onModelChange: null
    }, options);

    // Viewport transform
    this.panX = 0;
    this.panY = 0;
    this.zoom = 1;
    this.dpr = window.devicePixelRatio || 1;

    // Interaction state
    this.currentTool = 'select'; // 'select' | 'add-state' | 'add-transition' | 'toggle-initial' | 'toggle-final' | 'delete'
    this.selectedState = null;
    this.selectedTransition = null;
    this.activeStateIds = new Set(); // Highlighted during simulation
    this.activeTransitionIds = new Set();

    // Dragging
    this.isDragging = false;
    this.draggedState = null;
    this.dragStartX = 0;
    this.dragStartY = 0;
    this.isPanning = false;
    this.panStartX = 0;
    this.panStartY = 0;

    // Creating transition
    this.transitionSource = null;
    this.mouseWorldPos = { x: 0, y: 0 };

    this.initEvents();
    this.resize();
    this.render();
  }

  resize() {
    const rect = this.canvas.parentElement.getBoundingClientRect();
    const width = Math.max(rect.width, 300);
    const height = Math.max(rect.height, 300);

    this.canvas.width = width * this.dpr;
    this.canvas.height = height * this.dpr;
    this.canvas.style.width = `${width}px`;
    this.canvas.style.height = `${height}px`;

    this.render();
  }

  setTool(tool) {
    this.currentTool = tool;
    this.selectedState = null;
    this.selectedTransition = null;
    this.transitionSource = null;
    this.render();
  }

  setActiveStates(stateIds) {
    this.activeStateIds = new Set(stateIds || []);
    this.render();
  }

  setActiveTransitions(transIds) {
    this.activeTransitionIds = new Set(transIds || []);
    this.render();
  }

  screenToWorld(clientX, clientY) {
    const rect = this.canvas.getBoundingClientRect();
    const sx = clientX - rect.left;
    const sy = clientY - rect.top;
    return {
      x: (sx - this.panX) / this.zoom,
      y: (sy - this.panY) / this.zoom
    };
  }

  hitTestState(x, y) {
    for (const s of Array.from(this.automaton.states.values()).reverse()) {
      const dx = s.x - x;
      const dy = s.y - y;
      if (Math.sqrt(dx * dx + dy * dy) <= s.radius + 4) {
        return s;
      }
    }
    return null;
  }

  hitTestTransition(x, y) {
    for (const t of this.automaton.transitions) {
      const from = this.automaton.getState(t.from);
      const to = this.automaton.getState(t.to);
      if (!from || !to) continue;

      const mid = this.getTransitionMidpoint(from, to, t);
      const dx = mid.x - x;
      const dy = mid.y - y;
      if (Math.sqrt(dx * dx + dy * dy) <= 18) {
        return t;
      }
    }
    return null;
  }

  initEvents() {
    window.addEventListener('resize', () => this.resize());

    // Mouse Down
    this.canvas.addEventListener('mousedown', (e) => {
      if (e.button === 1 || e.code === 'Space' || (e.button === 0 && e.altKey)) {
        // Pan canvas
        this.isPanning = true;
        this.panStartX = e.clientX - this.panX;
        this.panStartY = e.clientY - this.panY;
        return;
      }

      if (e.button !== 0) return; // Left click only

      const world = this.screenToWorld(e.clientX, e.clientY);
      const hitState = this.hitTestState(world.x, world.y);
      const hitTrans = this.hitTestTransition(world.x, world.y);

      if (this.currentTool === 'select') {
        if (hitState) {
          this.selectedState = hitState;
          this.selectedTransition = null;
          this.isDragging = true;
          this.draggedState = hitState;
          this.dragStartX = world.x - hitState.x;
          this.dragStartY = world.y - hitState.y;
          if (this.options.onStateSelect) this.options.onStateSelect(hitState);
        } else if (hitTrans) {
          this.selectedTransition = hitTrans;
          this.selectedState = null;
        } else {
          this.selectedState = null;
          this.selectedTransition = null;
        }
      } else if (this.currentTool === 'add-state') {
        if (!hitState) {
          const newState = this.automaton.addState(null, Math.round(world.x), Math.round(world.y));
          if (this.automaton.states.size === 1) {
            newState.isInitial = true;
          }
          this.selectedState = newState;
          this.notifyModelChange();
        }
      } else if (this.currentTool === 'add-transition') {
        if (hitState) {
          this.transitionSource = hitState;
        }
      } else if (this.currentTool === 'toggle-initial') {
        if (hitState) {
          this.automaton.setInitialState(hitState.id);
          this.notifyModelChange();
        }
      } else if (this.currentTool === 'toggle-final') {
        if (hitState) {
          this.automaton.toggleFinalState(hitState.id);
          this.notifyModelChange();
        }
      } else if (this.currentTool === 'delete') {
        if (hitState) {
          this.automaton.removeState(hitState.id);
          this.notifyModelChange();
        } else if (hitTrans) {
          this.automaton.removeTransition(hitTrans.id);
          this.notifyModelChange();
        }
      }

      this.render();
    });

    // Mouse Move
    this.canvas.addEventListener('mousemove', (e) => {
      const world = this.screenToWorld(e.clientX, e.clientY);
      this.mouseWorldPos = world;

      if (this.isPanning) {
        this.panX = e.clientX - this.panStartX;
        this.panY = e.clientY - this.panStartY;
        this.render();
        return;
      }

      if (this.isDragging && this.draggedState) {
        this.draggedState.x = Math.round(world.x - this.dragStartX);
        this.draggedState.y = Math.round(world.y - this.dragStartY);
        this.render();
        return;
      }

      if (this.currentTool === 'add-transition' && this.transitionSource) {
        this.render();
      }
    });

    // Mouse Up
    window.addEventListener('mouseup', (e) => {
      if (this.isPanning) {
        this.isPanning = false;
      }

      if (this.isDragging) {
        this.isDragging = false;
        this.draggedState = null;
        this.notifyModelChange();
      }

      if (this.currentTool === 'add-transition' && this.transitionSource) {
        const world = this.screenToWorld(e.clientX, e.clientY);
        const targetState = this.hitTestState(world.x, world.y);

        if (targetState) {
          // Open transition dialog or default symbol
          this.onTransitionPrompt(this.transitionSource, targetState);
        }

        this.transitionSource = null;
        this.render();
      }
    });

    // Double Click
    this.canvas.addEventListener('dblclick', (e) => {
      const world = this.screenToWorld(e.clientX, e.clientY);
      const hitState = this.hitTestState(world.x, world.y);
      const hitTrans = this.hitTestTransition(world.x, world.y);

      if (hitState && this.options.onStateDoubleClick) {
        this.options.onStateDoubleClick(hitState);
      } else if (hitTrans && this.options.onTransitionDoubleClick) {
        this.options.onTransitionDoubleClick(hitTrans);
      }
    });

    // Zoom Wheel
    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
      const newZoom = Math.min(Math.max(this.zoom * zoomFactor, 0.3), 3.0);

      const rect = this.canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      // Zoom centered at mouse cursor
      this.panX = mouseX - (mouseX - this.panX) * (newZoom / this.zoom);
      this.panY = mouseY - (mouseY - this.panY) * (newZoom / this.zoom);
      this.zoom = newZoom;

      this.render();
    }, { passive: false });
  }

  onTransitionPrompt(fromState, toState) {
    if (this.options.onAddTransitionPrompt) {
      this.options.onAddTransitionPrompt(fromState, toState);
    } else {
      // Default: add symbol '0'
      const sym = prompt(`Enter transition symbol(s) from ${fromState.name} to ${toState.name} (comma-separated, use 'ε' for epsilon):`, '0');
      if (sym !== null && sym.trim() !== '') {
        const symbols = sym.split(',').map(s => s.trim()).filter(Boolean);
        this.automaton.addTransition(fromState.id, toState.id, symbols);
        this.notifyModelChange();
        this.render();
      }
    }
  }

  notifyModelChange() {
    if (this.options.onModelChange) {
      this.options.onModelChange();
    }
  }

  resetView() {
    this.panX = 0;
    this.panY = 0;
    this.zoom = 1;
    this.render();
  }

  autoLayout() {
    const states = Array.from(this.automaton.states.values());
    if (states.length === 0) return;

    const rect = this.canvas.parentElement.getBoundingClientRect();
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    if (states.length === 1) {
      states[0].x = centerX;
      states[0].y = centerY;
    } else {
      // Circle layout with comfortable radius
      const radius = Math.min(rect.width, rect.height) * 0.32;
      const angleStep = (2 * Math.PI) / states.length;

      states.forEach((s, idx) => {
        const angle = idx * angleStep - Math.PI / 2;
        s.x = Math.round(centerX + radius * Math.cos(angle));
        s.y = Math.round(centerY + radius * Math.sin(angle));
      });
    }

    this.notifyModelChange();
    this.render();
  }

  getTransitionMidpoint(from, to, trans) {
    if (from.id === to.id) {
      // Self loop midpoint above state
      return { x: from.x, y: from.y - from.radius - 32 };
    }

    const midX = (from.x + to.x) / 2;
    const midY = (from.y + to.y) / 2;

    if (trans.curve === 0) {
      return { x: midX, y: midY };
    }

    // Normal vector perpendicular to line
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const len = Math.sqrt(dx * dx + dy * dy) || 1;
    const nx = -dy / len;
    const ny = dx / len;

    return {
      x: midX + nx * trans.curve,
      y: midY + ny * trans.curve
    };
  }

  // ==========================================================
  // Canvas Rendering Pipeline
  // ==========================================================
  render() {
    const ctx = this.ctx;
    ctx.save();
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Apply DPI scaling and Pan/Zoom
    ctx.scale(this.dpr, this.dpr);
    ctx.translate(this.panX, this.panY);
    ctx.scale(this.zoom, this.zoom);

    // Render Transitions
    for (const t of this.automaton.transitions) {
      this.drawTransition(t);
    }

    // Render transition in progress
    if (this.currentTool === 'add-transition' && this.transitionSource) {
      this.drawTemporaryTransition(this.transitionSource, this.mouseWorldPos);
    }

    // Render States
    for (const s of this.automaton.states.values()) {
      this.drawState(s);
    }

    ctx.restore();
  }

  drawState(state) {
    const ctx = this.ctx;
    const isSelected = this.selectedState === state;
    const isActive = this.activeStateIds.has(state.id);

    // Glowing active aura during simulation
    if (isActive) {
      ctx.beginPath();
      ctx.arc(state.x, state.y, state.radius + 8, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(245, 158, 11, 0.25)';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(state.x, state.y, state.radius + 4, 0, Math.PI * 2);
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }

    // Initial state arrow
    if (state.isInitial) {
      const arrowStartX = state.x - state.radius - 28;
      const arrowEndX = state.x - state.radius - 2;
      const arrowY = state.y;

      ctx.beginPath();
      ctx.moveTo(arrowStartX, arrowY);
      ctx.lineTo(arrowEndX, arrowY);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Arrowhead
      ctx.beginPath();
      ctx.moveTo(arrowEndX, arrowY);
      ctx.lineTo(arrowEndX - 8, arrowY - 6);
      ctx.lineTo(arrowEndX - 8, arrowY + 6);
      ctx.closePath();
      ctx.fillStyle = '#38bdf8';
      ctx.fill();
    }

    // State Main Circle
    ctx.beginPath();
    ctx.arc(state.x, state.y, state.radius, 0, Math.PI * 2);
    ctx.fillStyle = isSelected ? '#1e293b' : (isActive ? '#292524' : '#111827');
    ctx.fill();

    ctx.strokeStyle = isSelected ? '#38bdf8' : (isActive ? '#f59e0b' : '#4b5563');
    ctx.lineWidth = isSelected ? 3 : 2;
    ctx.stroke();

    // Final state inner circle ◎
    if (state.isFinal) {
      ctx.beginPath();
      ctx.arc(state.x, state.y, state.radius - 5, 0, Math.PI * 2);
      ctx.strokeStyle = isSelected ? '#38bdf8' : (isActive ? '#f59e0b' : '#10b981');
      ctx.lineWidth = 1.8;
      ctx.stroke();
    }

    // State Label
    ctx.fillStyle = '#f9fafb';
    ctx.font = '600 13px "Fira Code", monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (this.automaton.type === 'MOORE' && state.output !== undefined && state.output !== '') {
      // Moore state format: q0 / out
      ctx.fillText(state.name, state.x, state.y - 6);
      ctx.font = '500 11px "Fira Code", monospace';
      ctx.fillStyle = '#34d399';
      ctx.fillText(`/${state.output}`, state.x, state.y + 8);
    } else {
      ctx.fillText(state.name, state.x, state.y);
    }
  }

  drawTransition(trans) {
    const from = this.automaton.getState(trans.from);
    const to = this.automaton.getState(trans.to);
    if (!from || !to) return;

    const ctx = this.ctx;
    const isSelected = this.selectedTransition === trans;
    const isActive = this.activeTransitionIds.has(trans.id);

    const strokeColor = isSelected ? '#38bdf8' : (isActive ? '#f59e0b' : '#64748b');
    const lineWidth = isSelected || isActive ? 2.5 : 1.8;

    ctx.strokeStyle = strokeColor;
    ctx.fillStyle = strokeColor;
    ctx.lineWidth = lineWidth;

    if (from.id === to.id) {
      // ================= Self Loop =================
      const loopRadius = 20;
      const loopCenterX = from.x;
      const loopCenterY = from.y - from.radius - loopRadius + 6;

      ctx.beginPath();
      ctx.arc(loopCenterX, loopCenterY, loopRadius, Math.PI * 0.15, Math.PI * 0.85, true);
      ctx.stroke();

      // Arrowhead for self loop
      const arrowX = from.x + from.radius * Math.cos(-Math.PI * 0.35);
      const arrowY = from.y + from.radius * Math.sin(-Math.PI * 0.35);

      this.drawArrowhead(arrowX - 4, arrowY - 8, arrowX, arrowY, strokeColor);

      // Label above loop
      this.drawTransitionLabel(loopCenterX, loopCenterY - loopRadius - 8, trans.getLabel(), isSelected);
    } else {
      // ================= Curved or Straight Arrow =================
      const dx = to.x - from.x;
      const dy = to.y - from.y;
      const dist = Math.sqrt(dx * dx + dy * dy) || 1;

      const mid = this.getTransitionMidpoint(from, to, trans);

      // Compute intersection with target circle radius
      const targetAngle = Math.atan2(to.y - mid.y, to.x - mid.x);
      const endX = to.x - to.radius * Math.cos(targetAngle);
      const endY = to.y - to.radius * Math.sin(targetAngle);

      // Intersection with source circle
      const sourceAngle = Math.atan2(mid.y - from.y, mid.x - from.x);
      const startX = from.x + from.radius * Math.cos(sourceAngle);
      const startY = from.y + from.radius * Math.sin(sourceAngle);

      // Draw quadratic curve
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.quadraticCurveTo(mid.x, mid.y, endX, endY);
      ctx.stroke();

      // Arrowhead at end
      this.drawArrowhead(mid.x, mid.y, endX, endY, strokeColor);

      // Draw label badge at curve control point
      this.drawTransitionLabel(mid.x, mid.y - 2, trans.getLabel(), isSelected);
    }
  }

  drawTemporaryTransition(from, mouse) {
    const ctx = this.ctx;
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);

    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(mouse.x, mouse.y);
    ctx.stroke();

    ctx.setLineDash([]);
    this.drawArrowhead(from.x, from.y, mouse.x, mouse.y, '#38bdf8');
  }

  drawArrowhead(fromX, fromY, toX, toY, color) {
    const ctx = this.ctx;
    const angle = Math.atan2(toY - fromY, toX - fromX);
    const arrowSize = 10;

    ctx.save();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(toX, toY);
    ctx.lineTo(
      toX - arrowSize * Math.cos(angle - Math.PI / 7),
      toY - arrowSize * Math.sin(angle - Math.PI / 7)
    );
    ctx.lineTo(
      toX - arrowSize * Math.cos(angle + Math.PI / 7),
      toY - arrowSize * Math.sin(angle + Math.PI / 7)
    );
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  drawTransitionLabel(x, y, text, isSelected) {
    const ctx = this.ctx;
    ctx.font = '600 12px "Fira Code", monospace';
    const textMetrics = ctx.measureText(text);
    const paddingX = 6;
    const paddingY = 3;
    const width = textMetrics.width + paddingX * 2;
    const height = 18;

    // Label pill background
    ctx.save();
    ctx.fillStyle = isSelected ? '#1e293b' : 'rgba(15, 23, 42, 0.92)';
    ctx.strokeStyle = isSelected ? '#38bdf8' : '#334155';
    ctx.lineWidth = 1;

    ctx.beginPath();
    const rx = x - width / 2;
    const ry = y - height / 2;
    const r = 4;
    ctx.roundRect(rx, ry, width, height, r);
    ctx.fill();
    ctx.stroke();

    // Label text
    ctx.fillStyle = isSelected ? '#38bdf8' : '#e2e8f0';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, x, y);
    ctx.restore();
  }
}
