/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * L-Systems (Lindenmayer Systems) Parallel Rewriting & Turtle Graphics Renderer
 */

class LSystemEngine {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement.getContext('2d');
    this.dpr = window.devicePixelRatio || 1;

    this.presets = {
      koch: {
        name: 'Koch Snowflake',
        axiom: 'F--F--F',
        rules: { 'F': 'F+F--F+F' },
        angle: 60,
        iterations: 3
      },
      sierpinski: {
        name: 'Sierpinski Triangle',
        axiom: 'F-G-G',
        rules: { 'F': 'F-G+F+G-F', 'G': 'GG' },
        angle: 120,
        iterations: 4
      },
      dragon: {
        name: 'Dragon Curve',
        axiom: 'FX',
        rules: { 'X': 'X+YF+', 'Y': '-FX-Y' },
        angle: 90,
        iterations: 9
      },
      plant: {
        name: 'Barnsley Fern / Plant',
        axiom: 'X',
        rules: { 'X': 'F+[[X]-X]-F[-FX]+X', 'F': 'FF' },
        angle: 25,
        iterations: 4
      },
      tree: {
        name: 'Fractal Tree',
        axiom: 'F',
        rules: { 'F': 'FF+[+F-F-F]-[-F+F+F]' },
        angle: 22.5,
        iterations: 3
      }
    };
  }

  expand(axiom, rules, iterations) {
    let current = axiom;
    for (let i = 0; i < iterations; i++) {
      let next = '';
      for (let j = 0; j < current.length; j++) {
        const char = current[j];
        next += rules[char] !== undefined ? rules[char] : char;
      }
      current = next;
    }
    return current;
  }

  render(axiom, rules, angleDeg, iterations) {
    const string = this.expand(axiom, rules, iterations);
    this.drawTurtle(string, angleDeg);
    return string;
  }

  drawTurtle(string, angleDeg) {
    const canvas = this.canvas;
    const ctx = this.ctx;
    const rect = canvas.parentElement.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    canvas.width = width * this.dpr;
    canvas.height = height * this.dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    ctx.save();
    ctx.scale(this.dpr, this.dpr);
    ctx.clearRect(0, 0, width, height);

    const radAngle = (angleDeg * Math.PI) / 180;
    const stepLength = 10;

    // Pass 1: Compute Bounding Box
    let x = 0;
    let y = 0;
    let dir = -Math.PI / 2; // Default facing up
    let minX = 0, maxX = 0, minY = 0, maxY = 0;
    const stack = [];

    for (let i = 0; i < string.length; i++) {
      const cmd = string[i];
      if (cmd === 'F' || cmd === 'G') {
        x += stepLength * Math.cos(dir);
        y += stepLength * Math.sin(dir);
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      } else if (cmd === '+') {
        dir += radAngle;
      } else if (cmd === '-') {
        dir -= radAngle;
      } else if (cmd === '[') {
        stack.push({ x, y, dir });
      } else if (cmd === ']') {
        const state = stack.pop();
        if (state) {
          x = state.x;
          y = state.y;
          dir = state.dir;
        }
      }
    }

    // Compute Scale & Offset to fit perfectly inside canvas with margin
    const bboxW = maxX - minX || 1;
    const bboxH = maxY - minY || 1;
    const margin = 40;
    const scale = Math.min((width - margin * 2) / bboxW, (height - margin * 2) / bboxH);

    const offsetX = (width - bboxW * scale) / 2 - minX * scale;
    const offsetY = (height - bboxH * scale) / 2 - minY * scale;

    // Pass 2: Draw the Fractal
    x = 0;
    y = 0;
    dir = -Math.PI / 2;
    stack.length = 0;

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();

    for (let i = 0; i < string.length; i++) {
      const cmd = string[i];
      if (cmd === 'F' || cmd === 'G') {
        const nx = x + stepLength * Math.cos(dir);
        const ny = y + stepLength * Math.sin(dir);

        ctx.moveTo(x * scale + offsetX, y * scale + offsetY);
        ctx.lineTo(nx * scale + offsetX, ny * scale + offsetY);

        x = nx;
        y = ny;
      } else if (cmd === '+') {
        dir += radAngle;
      } else if (cmd === '-') {
        dir -= radAngle;
      } else if (cmd === '[') {
        stack.push({ x, y, dir });
      } else if (cmd === ']') {
        const state = stack.pop();
        if (state) {
          x = state.x;
          y = state.y;
          dir = state.dir;
        }
      }
    }

    ctx.stroke();
    ctx.restore();
  }
}
