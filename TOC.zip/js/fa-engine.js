/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * FA Engine: DFA / NFA / ε-NFA Simulation, Epsilon Closure, Step Tracing & Batch Testing
 */

class FAEngine {
  constructor(automaton) {
    this.automaton = automaton;
    this.reset();
  }

  reset() {
    this.inputString = '';
    this.charIndex = 0;
    this.activeStates = new Set();
    this.isRunning = false;
    this.isFinished = false;
    this.isAccepted = false;
    this.history = []; // Array of step snapshots

    // Initialize with epsilon-closure of initial state
    const initial = this.automaton.getInitialState();
    if (initial) {
      this.activeStates = this.getEpsilonClosure(new Set([initial.id]));
    }
  }

  setInput(str) {
    this.inputString = str;
    this.charIndex = 0;
    this.isFinished = false;
    this.isAccepted = false;
    this.history = [];

    const initial = this.automaton.getInitialState();
    if (initial) {
      this.activeStates = this.getEpsilonClosure(new Set([initial.id]));
    } else {
      this.activeStates = new Set();
    }

    this.recordHistory('Initial state configuration');
  }

  isEpsilon(sym) {
    return sym === 'ε' || sym === 'e' || sym === 'λ' || sym === '';
  }

  // Compute epsilon-closure(T) for a set of state IDs T
  getEpsilonClosure(stateIds) {
    const closure = new Set(stateIds);
    const stack = Array.from(stateIds);

    while (stack.length > 0) {
      const currId = stack.pop();
      const outgoing = this.automaton.getTransitionsFrom(currId);

      for (const t of outgoing) {
        const hasEpsilon = t.symbols.some(s => this.isEpsilon(s.trim()));
        if (hasEpsilon) {
          if (!closure.has(t.to)) {
            closure.add(t.to);
            stack.push(t.to);
          }
        }
      }
    }

    return closure;
  }

  // Execute a single step of simulation
  step() {
    if (this.isFinished) return null;

    if (!this.automaton.getInitialState()) {
      this.isFinished = true;
      this.isAccepted = false;
      return { error: 'No initial state defined' };
    }

    // Check if input is already exhausted
    if (this.charIndex >= this.inputString.length) {
      this.isFinished = true;
      this.isAccepted = this.checkAcceptance();
      this.recordHistory(`End of input reached. Verdict: ${this.isAccepted ? 'ACCEPTED' : 'REJECTED'}`);
      return {
        finished: true,
        accepted: this.isAccepted,
        activeStates: Array.from(this.activeStates),
        charRead: null,
        remaining: ''
      };
    }

    const char = this.inputString[this.charIndex];
    const nextStates = new Set();
    const traversedTransitions = [];

    // For every currently active state, find transitions on `char`
    for (const stateId of this.activeStates) {
      const outgoing = this.automaton.getTransitionsFrom(stateId);
      for (const t of outgoing) {
        if (t.symbols.some(s => s.trim() === char)) {
          nextStates.add(t.to);
          traversedTransitions.push(t.id);
        }
      }
    }

    // Expand next states with epsilon-closure
    const newActiveStates = this.getEpsilonClosure(nextStates);
    this.activeStates = newActiveStates;
    this.charIndex++;

    const remaining = this.inputString.slice(this.charIndex);
    const isAtEnd = this.charIndex >= this.inputString.length;

    if (isAtEnd) {
      this.isFinished = true;
      this.isAccepted = this.checkAcceptance();
    }

    const stateNames = Array.from(this.activeStates)
      .map(id => this.automaton.getState(id)?.name || `q${id}`)
      .join(', ');

    const logMsg = `Read '${char}' &rarr; Active: { ${stateNames || '∅ (Dead)'} } [Remaining: "${remaining}"]`;
    this.recordHistory(logMsg);

    return {
      finished: this.isFinished,
      accepted: this.isAccepted,
      activeStates: Array.from(this.activeStates),
      traversedTransitions,
      charRead: char,
      remaining
    };
  }

  checkAcceptance() {
    const finals = new Set(this.automaton.getFinalStates().map(s => s.id));
    for (const id of this.activeStates) {
      if (finals.has(id)) return true;
    }
    return false;
  }

  recordHistory(desc) {
    this.history.push({
      charIndex: this.charIndex,
      activeStates: Array.from(this.activeStates),
      desc
    });
  }

  // Fast test of a string without animations
  testString(str) {
    const initial = this.automaton.getInitialState();
    if (!initial) return false;

    let current = this.getEpsilonClosure(new Set([initial.id]));

    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      const next = new Set();

      for (const stateId of current) {
        const outgoing = this.automaton.getTransitionsFrom(stateId);
        for (const t of outgoing) {
          if (t.symbols.some(s => s.trim() === char)) {
            next.add(t.to);
          }
        }
      }

      current = this.getEpsilonClosure(next);
      if (current.size === 0) return false; // Dead configuration
    }

    const finals = new Set(this.automaton.getFinalStates().map(s => s.id));
    for (const id of current) {
      if (finals.has(id)) return true;
    }
    return false;
  }

  // Batch string execution
  runBatchTests(testStrings) {
    return testStrings.map(str => {
      const accepted = this.testString(str);
      return {
        string: str === '' ? 'ε' : str,
        accepted
      };
    });
  }

  // Generate Transition Table HTML
  generateTransitionTable() {
    const states = Array.from(this.automaton.states.values());
    if (states.length === 0) {
      return '<p class="empty-hint">No states in automaton.</p>';
    }

    const alphabet = this.automaton.getAlphabet();
    // Check if any epsilon transitions exist
    let hasEpsilon = false;
    for (const t of this.automaton.transitions) {
      if (t.symbols.some(s => this.isEpsilon(s.trim()))) {
        hasEpsilon = true;
        break;
      }
    }

    const columns = [...alphabet];
    if (hasEpsilon) columns.push('ε');

    let html = '<table class="clean-table">';
    html += '<thead><tr><th>State</th>';
    for (const sym of columns) {
      html += `<th>${sym}</th>`;
    }
    html += '</tr></thead><tbody>';

    for (const state of states) {
      let stateLabel = state.name;
      if (state.isInitial && state.isFinal) {
        stateLabel = `&rarr;* ${state.name}`;
      } else if (state.isInitial) {
        stateLabel = `&rarr; ${state.name}`;
      } else if (state.isFinal) {
        stateLabel = `* ${state.name}`;
      }

      html += `<tr><td class="state-name">${stateLabel}</td>`;

      const outgoing = this.automaton.getTransitionsFrom(state.id);

      for (const sym of columns) {
        const dests = [];
        for (const t of outgoing) {
          const matched = t.symbols.some(s => {
            const trimmed = s.trim();
            if (sym === 'ε') return this.isEpsilon(trimmed);
            return trimmed === sym;
          });

          if (matched) {
            const target = this.automaton.getState(t.to);
            if (target && !dests.includes(target.name)) {
              dests.push(target.name);
            }
          }
        }

        const cellText = dests.length === 0 ? '∅' : `{ ${dests.sort().join(', ')} }`;
        html += `<td>${cellText}</td>`;
      }

      html += '</tr>';
    }

    html += '</tbody></table>';
    return html;
  }
}
