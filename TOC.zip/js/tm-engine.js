/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Turing Machine Engine: Single-Tape & Multi-Tape Simulator with Infinite Tape Visualizer
 */

class TuringMachineEngine {
  constructor(automaton, tapeCount = 1) {
    this.automaton = automaton;
    this.automaton.type = 'TM';
    this.tapeCount = tapeCount;
    this.blankSymbol = '⊔';
    this.reset();
  }

  setTapeCount(count) {
    this.tapeCount = count;
    this.reset();
  }

  reset() {
    this.stepCount = 0;
    this.currentState = this.automaton.getInitialState();
    this.isHalted = false;
    this.isAccepted = false;
    this.history = [];

    // Infinite tape representations (Map from integer index -> symbol)
    this.tapes = Array.from({ length: this.tapeCount }, () => new Map());
    this.headPositions = Array.from({ length: this.tapeCount }, () => 0);

    if (this.currentState) {
      this.recordTrace('Initial TM tape configuration');
    }
  }

  setInput(str, tapeIndex = 0) {
    this.reset();
    const tape = this.tapes[tapeIndex];
    for (let i = 0; i < str.length; i++) {
      tape.set(i, str[i]);
    }
    this.headPositions[tapeIndex] = 0;
    this.recordTrace(`Loaded input "${str}" on Tape ${tapeIndex + 1}`);
  }

  readTape(tapeIdx, pos) {
    const val = this.tapes[tapeIdx].get(pos);
    return val !== undefined ? val : this.blankSymbol;
  }

  writeTape(tapeIdx, pos, symbol) {
    if (symbol === this.blankSymbol || symbol === '_' || symbol === '') {
      this.tapes[tapeIdx].delete(pos);
    } else {
      this.tapes[tapeIdx].set(pos, symbol);
    }
  }

  // Parse Single-Tape Rule: "read -> write, Move" (e.g. "0 -> 1, R" or "_ -> _, L")
  static parseSingleTapeRule(ruleStr) {
    const arrowParts = ruleStr.split('->').map(p => p.trim());
    if (arrowParts.length !== 2) return null;

    const read = arrowParts[0] === '_' ? '⊔' : arrowParts[0];
    const rightParts = arrowParts[1].split(',').map(p => p.trim());
    if (rightParts.length !== 2) return null;

    const write = rightParts[0] === '_' ? '⊔' : rightParts[0];
    const move = rightParts[1].toUpperCase(); // 'L' | 'R' | 'S'

    return { read, write, move };
  }

  // Parse Multi-Tape (2-Tape) Rule: "(0, _) -> (0, 0), (R, R)"
  static parseMultiTapeRule(ruleStr) {
    try {
      const arrowParts = ruleStr.split('->').map(p => p.trim());
      if (arrowParts.length !== 2) return null;

      // Clean parentheses
      const clean = str => str.replace(/[()]/g, '').trim();
      const readParts = clean(arrowParts[0]).split(',').map(s => s.trim() === '_' ? '⊔' : s.trim());

      const rightHalf = arrowParts[1];
      const match = rightHalf.match(/\(([^)]+)\)\s*,\s*\(([^)]+)\)/);
      if (!match) return null;

      const writeParts = match[1].split(',').map(s => s.trim() === '_' ? '⊔' : s.trim());
      const moveParts = match[2].split(',').map(s => s.trim().toUpperCase());

      return {
        reads: readParts,
        writes: writeParts,
        moves: moveParts
      };
    } catch (e) {
      return null;
    }
  }

  step() {
    if (this.isHalted || !this.currentState) return null;

    // Halt if already in accept state
    if (this.currentState.isFinal) {
      this.isHalted = true;
      this.isAccepted = true;
      this.recordTrace(`Halted in Accept state (${this.currentState.name})`);
      return { halted: true, accepted: true, currentState: this.currentState };
    }

    const outgoing = this.automaton.getTransitionsFrom(this.currentState.id);
    let matchedTrans = null;
    let matchedRule = null;

    if (this.tapeCount === 1) {
      const currentSym = this.readTape(0, this.headPositions[0]);

      for (const t of outgoing) {
        for (const s of t.symbols) {
          const rule = TuringMachineEngine.parseSingleTapeRule(s);
          if (rule && rule.read === currentSym) {
            matchedRule = rule;
            matchedTrans = t;
            break;
          }
        }
        if (matchedRule) break;
      }

      if (!matchedRule) {
        this.isHalted = true;
        this.isAccepted = this.currentState.isFinal;
        this.recordTrace(`No rule for state ${this.currentState.name} reading '${currentSym}'. Halted (${this.isAccepted ? 'ACCEPT' : 'REJECT'}).`);
        return { halted: true, accepted: this.isAccepted, currentState: this.currentState };
      }

      // Write and Move
      this.writeTape(0, this.headPositions[0], matchedRule.write);
      if (matchedRule.move === 'R') this.headPositions[0]++;
      else if (matchedRule.move === 'L') this.headPositions[0]--;

      this.currentState = this.automaton.getState(matchedTrans.to);
      this.stepCount++;

      if (this.currentState.isFinal) {
        this.isHalted = true;
        this.isAccepted = true;
      }

      this.recordTrace(`Read '${matchedRule.read}' &rarr; Write '${matchedRule.write}', Move ${matchedRule.move} &rarr; ${this.currentState.name}`);

      return {
        halted: this.isHalted,
        accepted: this.isAccepted,
        currentState: this.currentState,
        headPositions: [...this.headPositions],
        stepCount: this.stepCount
      };
    } else {
      // 2-Tape Mode
      const sym1 = this.readTape(0, this.headPositions[0]);
      const sym2 = this.readTape(1, this.headPositions[1]);

      for (const t of outgoing) {
        for (const s of t.symbols) {
          const rule = TuringMachineEngine.parseMultiTapeRule(s);
          if (rule && rule.reads[0] === sym1 && rule.reads[1] === sym2) {
            matchedRule = rule;
            matchedTrans = t;
            break;
          }
        }
        if (matchedRule) break;
      }

      if (!matchedRule) {
        this.isHalted = true;
        this.isAccepted = this.currentState.isFinal;
        this.recordTrace(`No 2-tape rule matching (${sym1}, ${sym2}). Halted (${this.isAccepted ? 'ACCEPT' : 'REJECT'}).`);
        return { halted: true, accepted: this.isAccepted, currentState: this.currentState };
      }

      // Execute on both tapes
      this.writeTape(0, this.headPositions[0], matchedRule.writes[0]);
      if (matchedRule.moves[0] === 'R') this.headPositions[0]++;
      else if (matchedRule.moves[0] === 'L') this.headPositions[0]--;

      this.writeTape(1, this.headPositions[1], matchedRule.writes[1]);
      if (matchedRule.moves[1] === 'R') this.headPositions[1]++;
      else if (matchedRule.moves[1] === 'L') this.headPositions[1]--;

      this.currentState = this.automaton.getState(matchedTrans.to);
      this.stepCount++;

      if (this.currentState.isFinal) {
        this.isHalted = true;
        this.isAccepted = true;
      }

      this.recordTrace(`Read (${sym1}, ${sym2}) &rarr; Write (${matchedRule.writes[0]}, ${matchedRule.writes[1]}), Move (${matchedRule.moves[0]}, ${matchedRule.moves[1]}) &rarr; ${this.currentState.name}`);

      return {
        halted: this.isHalted,
        accepted: this.isAccepted,
        currentState: this.currentState,
        headPositions: [...this.headPositions],
        stepCount: this.stepCount
      };
    }
  }

  // Get visible tape cells window around head position
  getTapeWindow(tapeIdx, windowRadius = 8) {
    const head = this.headPositions[tapeIdx];
    const cells = [];

    for (let i = head - windowRadius; i <= head + windowRadius; i++) {
      cells.push({
        index: i,
        symbol: this.readTape(tapeIdx, i),
        isHead: (i === head)
      });
    }

    return cells;
  }

  recordTrace(desc) {
    let idDesc = '';
    if (this.tapeCount === 1) {
      idDesc = `Tape 1: pos=${this.headPositions[0]}, val='${this.readTape(0, this.headPositions[0])}'`;
    } else {
      idDesc = `T1[${this.headPositions[0]}]='${this.readTape(0, this.headPositions[0])}', T2[${this.headPositions[1]}]='${this.readTape(1, this.headPositions[1])}'`;
    }

    this.history.push({
      step: this.stepCount,
      state: this.currentState?.name || '?',
      info: idDesc,
      desc
    });
  }

  // Generate HTML table of transitions
  generateTransitionsTable() {
    const states = Array.from(this.automaton.states.values());
    if (states.length === 0) return '<p class="empty-hint">No states in Turing Machine.</p>';

    let html = '<table class="clean-table">';
    html += '<thead><tr><th>From</th><th>Condition &amp; Action</th><th>To</th></tr></thead><tbody>';

    for (const t of this.automaton.transitions) {
      const from = this.automaton.getState(t.from);
      const to = this.automaton.getState(t.to);
      if (!from || !to) continue;

      for (const s of t.symbols) {
        html += `<tr>
          <td class="state-name">${from.name}</td>
          <td><code>${s}</code></td>
          <td class="state-name">${to.name}</td>
        </tr>`;
      }
    }

    html += '</tbody></table>';
    return html;
  }
}
