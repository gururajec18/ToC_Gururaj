/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Pushdown Automata (PDA) Engine & CFG -> PDA Converter
 */

class PDAEngine {
  constructor(automaton) {
    this.automaton = automaton;
    this.automaton.type = 'PDA';
    this.acceptMode = 'final'; // 'final' | 'empty' | 'both'
    this.reset();
  }

  reset() {
    this.inputString = '';
    this.charIndex = 0;
    this.currentState = this.automaton.getInitialState();
    this.stack = ['Z0']; // Initial stack symbol
    this.history = [];
    this.isFinished = false;
    this.isAccepted = false;

    if (this.currentState) {
      this.recordTrace('Initial configuration');
    }
  }

  setInput(str, mode = 'final') {
    this.inputString = str;
    this.acceptMode = mode;
    this.reset();
  }

  isEpsilon(sym) {
    return sym === 'ε' || sym === 'e' || sym === 'λ' || sym === '';
  }

  // Parse transition string "a, X -> α" or "a,X->α"
  static parsePDARule(ruleStr) {
    // Format: input, pop -> push
    const arrowParts = ruleStr.split('->').map(p => p.trim());
    if (arrowParts.length !== 2) return null;

    const leftParts = arrowParts[0].split(',').map(p => p.trim());
    if (leftParts.length !== 2) return null;

    return {
      input: leftParts[0],
      pop: leftParts[1],
      push: arrowParts[1] // Can be 'ε' or string of stack symbols
    };
  }

  step() {
    if (this.isFinished || !this.currentState) return null;

    const remainingInput = this.inputString.slice(this.charIndex);
    const currentChar = this.charIndex < this.inputString.length ? this.inputString[this.charIndex] : '';
    const topOfStack = this.stack.length > 0 ? this.stack[this.stack.length - 1] : null;

    if (topOfStack === null && currentChar === '') {
      // Empty stack and empty input
      this.isFinished = true;
      this.isAccepted = (this.acceptMode === 'empty' || this.acceptMode === 'both' || this.currentState.isFinal);
      this.recordTrace(`Halted. Verdict: ${this.isAccepted ? 'ACCEPTED' : 'REJECTED'}`);
      return { finished: true, accepted: this.isAccepted, stack: [...this.stack] };
    }

    const outgoing = this.automaton.getTransitionsFrom(this.currentState.id);
    let matchedRule = null;
    let matchedTrans = null;
    let consumesInput = false;

    // Check transitions
    for (const t of outgoing) {
      for (const sym of t.symbols) {
        const parsed = PDAEngine.parsePDARule(sym);
        if (!parsed) continue;

        // Check if stack top matches pop condition
        const stackMatches = this.isEpsilon(parsed.pop) || (topOfStack && parsed.pop === topOfStack);
        if (!stackMatches) continue;

        // Check if input matches
        if (currentChar && parsed.input === currentChar) {
          matchedRule = parsed;
          matchedTrans = t;
          consumesInput = true;
          break;
        } else if (this.isEpsilon(parsed.input)) {
          // Epsilon input transition
          matchedRule = parsed;
          matchedTrans = t;
          consumesInput = false;
          break;
        }
      }
      if (matchedRule) break;
    }

    if (!matchedRule) {
      this.isFinished = true;
      this.isAccepted = this.checkAcceptance();
      this.recordTrace(`No applicable transition. Finished. Verdict: ${this.isAccepted ? 'ACCEPTED' : 'REJECTED'}`);
      return {
        finished: true,
        accepted: this.isAccepted,
        stack: [...this.stack]
      };
    }

    // Apply Transition
    if (consumesInput) {
      this.charIndex++;
    }

    // Pop from stack if not epsilon
    if (!this.isEpsilon(matchedRule.pop)) {
      this.stack.pop();
    }

    // Push to stack (push string in reverse so first char ends up on top)
    if (!this.isEpsilon(matchedRule.push)) {
      const toPush = matchedRule.push.split('').reverse();
      for (const ch of toPush) {
        this.stack.push(ch);
      }
    }

    this.currentState = this.automaton.getState(matchedTrans.to);

    const isEnd = (this.charIndex >= this.inputString.length);
    if (isEnd) {
      this.isAccepted = this.checkAcceptance();
    }

    const actionDesc = `${consumesInput ? `Read '${currentChar}'` : 'ε-move'}, Pop '${matchedRule.pop}', Push '${matchedRule.push}' &rarr; ${this.currentState.name}`;
    this.recordTrace(actionDesc);

    return {
      finished: isEnd && this.isAccepted,
      accepted: this.isAccepted,
      currentState: this.currentState,
      stack: [...this.stack],
      remainingInput: this.inputString.slice(this.charIndex),
      traversedTransitionId: matchedTrans.id
    };
  }

  checkAcceptance() {
    const isAtEnd = (this.charIndex >= this.inputString.length);
    if (!isAtEnd) return false;

    const isFinalState = this.currentState.isFinal;
    const isEmptyStack = (this.stack.length === 0 || (this.stack.length === 1 && this.stack[0] === 'Z0'));

    if (this.acceptMode === 'final') return isFinalState;
    if (this.acceptMode === 'empty') return isEmptyStack;
    if (this.acceptMode === 'both') return isFinalState && isEmptyStack;
    return false;
  }

  recordTrace(desc) {
    const stackStr = this.stack.slice().reverse().join('') || 'ε';
    const remaining = this.inputString.slice(this.charIndex) || 'ε';
    const idStr = `(${this.currentState?.name || '?'}, "${remaining}", "${stackStr}")`;

    this.history.push({
      id: idStr,
      desc
    });
  }

  // Convert CFG to Top-Down PDA
  static cfgToPda(cfgRulesText) {
    const pda = new Automaton('PDA');
    const q0 = pda.addState('q0', 120, 240, true, false);
    const q1 = pda.addState('q1', 320, 240, false, false);
    const q2 = pda.addState('q2', 520, 240, false, true);

    const lines = cfgRulesText.split('\n').map(l => l.trim()).filter(Boolean);
    let startSymbol = 'S';

    const rules = [];
    const terminals = new Set();
    const nonTerminals = new Set();

    for (const line of lines) {
      const parts = line.split('->').map(p => p.trim());
      if (parts.length === 2) {
        const lhs = parts[0];
        nonTerminals.add(lhs);
        if (rules.length === 0) startSymbol = lhs;

        const alts = parts[1].split('|').map(a => a.trim());
        for (const alt of alts) {
          rules.push({ lhs, rhs: alt });
          for (const ch of alt) {
            if (!/[A-Z']/.test(ch) && ch !== 'ε' && ch !== 'e') {
              terminals.add(ch);
            }
          }
        }
      }
    }

    // Step 1: Initial transition q0 --ε, Z0 -> S Z0--> q1
    pda.addTransition(q0.id, q1.id, [`ε, Z0 -> ${startSymbol}Z0`]);

    // Step 2: Self loops on q1
    const loopSymbols = [];

    // Variable expansion: ε, A -> α
    for (const r of rules) {
      loopSymbols.push(`ε, ${r.lhs} -> ${r.rhs}`);
    }

    // Terminal matching: a, a -> ε
    for (const term of terminals) {
      loopSymbols.push(`${term}, ${term} -> ε`);
    }

    pda.addTransition(q1.id, q1.id, loopSymbols);

    // Step 3: Final acceptance transition q1 --ε, Z0 -> Z0--> q2
    pda.addTransition(q1.id, q2.id, ['ε, Z0 -> Z0']);

    return {
      pda,
      rules,
      terminals: Array.from(terminals),
      nonTerminals: Array.from(nonTerminals)
    };
  }
}
