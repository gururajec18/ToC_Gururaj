/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Conversions & Algorithms:
 * 1. NFA -> DFA Subset Construction
 * 2. DFA Minimization (Table-Filling / Hopcroft)
 * 3. FA -> Regex (State Elimination Method / Arden's)
 * 4. Regex -> ε-NFA (Thompson's Construction)
 * 5. Regular Grammar <-> Finite Automata
 */

class AutomataConversions {
  // Helper to test epsilon
  static isEpsilon(sym) {
    return sym === 'ε' || sym === 'e' || sym === 'λ' || sym === '';
  }

  // ===================================================================
  // 1. NFA -> DFA SUBSET CONSTRUCTION
  // ===================================================================
  static nfaToDfa(nfa) {
    const initial = nfa.getInitialState();
    if (!initial) {
      throw new Error('NFA has no initial state defined.');
    }

    const alphabet = nfa.getAlphabet();
    if (alphabet.length === 0) {
      throw new Error('Automaton has no alphabet symbols.');
    }

    const faEngine = new FAEngine(nfa);

    // Initial DFA state: epsilon-closure of NFA initial state
    const startClosure = Array.from(faEngine.getEpsilonClosure(new Set([initial.id]))).sort((a, b) => a - b);
    const startKey = startClosure.join(',');

    const subsetsMap = new Map(); // key -> { id, name, set, isFinal }
    const queue = [startClosure];
    let dfaStateCounter = 0;

    const nfaFinals = new Set(nfa.getFinalStates().map(s => s.id));

    function getSubsetName(setArray) {
      if (setArray.length === 0) return '∅';
      return '{' + setArray.map(id => nfa.getState(id)?.name || `q${id}`).join(',') + '}';
    }

    subsetsMap.set(startKey, {
      id: dfaStateCounter++,
      name: `D0: ${getSubsetName(startClosure)}`,
      set: startClosure,
      isInitial: true,
      isFinal: startClosure.some(id => nfaFinals.has(id))
    });

    const transitionsTable = []; // Array of { source, moves: { [sym]: targetKey } }
    const dfaTransitions = []; // { fromKey, toKey, sym }

    while (queue.length > 0) {
      const currentSet = queue.shift();
      const currentKey = currentSet.join(',');
      const rowMoves = {};

      for (const sym of alphabet) {
        // Move(currentSet, sym)
        const moveSet = new Set();
        for (const stateId of currentSet) {
          const out = nfa.getTransitionsFrom(stateId);
          for (const t of out) {
            if (t.symbols.some(s => s.trim() === sym)) {
              moveSet.add(t.to);
            }
          }
        }

        // Epsilon-closure of Move
        const nextClosure = Array.from(faEngine.getEpsilonClosure(moveSet)).sort((a, b) => a - b);
        const nextKey = nextClosure.join(',');

        if (nextClosure.length > 0) {
          if (!subsetsMap.has(nextKey)) {
            subsetsMap.set(nextKey, {
              id: dfaStateCounter++,
              name: `D${dfaStateCounter - 1}: ${getSubsetName(nextClosure)}`,
              set: nextClosure,
              isInitial: false,
              isFinal: nextClosure.some(id => nfaFinals.has(id))
            });
            queue.push(nextClosure);
          }
          dfaTransitions.push({ fromKey: currentKey, toKey: nextKey, sym });
          rowMoves[sym] = subsetsMap.get(nextKey).name;
        } else {
          rowMoves[sym] = '∅ (Dead)';
        }
      }

      transitionsTable.push({
        state: subsetsMap.get(currentKey).name,
        isInitial: subsetsMap.get(currentKey).isInitial,
        isFinal: subsetsMap.get(currentKey).isFinal,
        moves: rowMoves
      });
    }

    // Build the concrete DFA Automaton
    const dfa = new Automaton('FA');
    const keyToDfaStateId = new Map();

    let stateIdx = 0;
    const totalStates = subsetsMap.size;
    const radius = Math.max(160, totalStates * 30);
    const centerX = 360;
    const centerY = 240;

    for (const [key, info] of subsetsMap.entries()) {
      const angle = (2 * Math.PI * stateIdx) / totalStates - Math.PI / 2;
      const x = Math.round(centerX + radius * Math.cos(angle));
      const y = Math.round(centerY + radius * Math.sin(angle));

      const s = dfa.addState(
        `D${info.id}`,
        x,
        y,
        info.isInitial,
        info.isFinal
      );
      keyToDfaStateId.set(key, s.id);
      stateIdx++;
    }

    for (const trans of dfaTransitions) {
      const fromId = keyToDfaStateId.get(trans.fromKey);
      const toId = keyToDfaStateId.get(trans.toKey);
      if (fromId !== undefined && toId !== undefined) {
        dfa.addTransition(fromId, toId, [trans.sym]);
      }
    }

    return {
      dfa,
      subsetsMap,
      alphabet,
      transitionsTable
    };
  }

  // ===================================================================
  // 2. DFA MINIMIZATION (Hopcroft / Myhill-Nerode Table-Filling)
  // ===================================================================
  static minimizeDfa(dfa) {
    const initial = dfa.getInitialState();
    if (!initial) throw new Error('DFA has no initial state.');

    const alphabet = dfa.getAlphabet();

    // Step 1: Reachable states elimination
    const reachable = new Set();
    const reachQueue = [initial.id];
    reachable.add(initial.id);

    while (reachQueue.length > 0) {
      const curr = reachQueue.shift();
      for (const t of dfa.getTransitionsFrom(curr)) {
        if (!reachable.has(t.to)) {
          reachable.add(t.to);
          reachQueue.push(t.to);
        }
      }
    }

    const stateList = Array.from(dfa.states.values())
      .filter(s => reachable.has(s.id))
      .sort((a, b) => a.id - b.id);

    const n = stateList.length;
    if (n <= 1) {
      return {
        minDfa: dfa.clone(),
        steps: ['DFA has only 1 reachable state and is already minimal.'],
        pairsTable: {}
      };
    }

    // Index mapping
    const idToIndex = new Map();
    stateList.forEach((s, idx) => idToIndex.set(s.id, idx));

    // Matrix for pairs (i, j) with i < j
    // table[i][j] = true if distinguishable
    const table = Array.from({ length: n }, () => Array(n).fill(false));
    const finalSet = new Set(dfa.getFinalStates().map(s => s.id));
    const steps = [];

    // Base case: Mark pairs (p, q) where one is final and one is non-final
    let baseCount = 0;
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const pFinal = finalSet.has(stateList[i].id);
        const qFinal = finalSet.has(stateList[j].id);
        if (pFinal !== qFinal) {
          table[i][j] = true;
          baseCount++;
        }
      }
    }
    steps.push(`Base Step: Marked ${baseCount} pairs having one Final and one Non-Final state.`);

    // Helper to get delta(state, sym)
    function getNextState(stateId, sym) {
      for (const t of dfa.getTransitionsFrom(stateId)) {
        if (t.symbols.some(s => s.trim() === sym)) {
          return t.to;
        }
      }
      return null;
    }

    // Iterative marking
    let changed = true;
    let round = 1;
    while (changed) {
      changed = false;
      let roundMarked = 0;

      for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
          if (!table[i][j]) {
            // Check for any symbol
            for (const sym of alphabet) {
              const nextP = getNextState(stateList[i].id, sym);
              const nextQ = getNextState(stateList[j].id, sym);

              if (nextP !== null && nextQ !== null && nextP !== nextQ) {
                const idxP = idToIndex.get(nextP);
                const idxQ = idToIndex.get(nextQ);
                if (idxP !== undefined && idxQ !== undefined) {
                  const minIdx = Math.min(idxP, idxQ);
                  const maxIdx = Math.max(idxP, idxQ);
                  if (table[minIdx][maxIdx]) {
                    table[i][j] = true;
                    changed = true;
                    roundMarked++;
                    break;
                  }
                }
              }
            }
          }
        }
      }

      if (roundMarked > 0) {
        steps.push(`Round ${round}: Marked ${roundMarked} additional distinguishable pairs.`);
        round++;
      }
    }

    // Find equivalence classes (unmarked pairs)
    const parent = Array.from({ length: n }, (_, i) => i);
    function find(i) {
      if (parent[i] === i) return i;
      parent[i] = find(parent[i]);
      return parent[i];
    }
    function union(i, j) {
      const rootI = find(i);
      const rootJ = find(j);
      if (rootI !== rootJ) parent[rootI] = rootJ;
    }

    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        if (!table[i][j]) {
          union(i, j);
        }
      }
    }

    const groups = new Map();
    for (let i = 0; i < n; i++) {
      const root = find(i);
      if (!groups.has(root)) groups.set(root, []);
      groups.get(root).push(stateList[i]);
    }

    steps.push(`Equivalence Classes: Resulting in ${groups.size} minimal states.`);

    // Build Minimized DFA
    const minDfa = new Automaton('FA');
    const groupToMinState = new Map();

    let gIdx = 0;
    const groupCount = groups.size;
    const radius = Math.max(140, groupCount * 30);

    for (const [root, members] of groups.entries()) {
      const names = members.map(m => m.name).join('/');
      const isInit = members.some(m => m.id === initial.id);
      const isFin = members.some(m => finalSet.has(m.id));

      const angle = (2 * Math.PI * gIdx) / groupCount - Math.PI / 2;
      const x = Math.round(360 + radius * Math.cos(angle));
      const y = Math.round(240 + radius * Math.sin(angle));

      const newState = minDfa.addState(`m${gIdx}`, x, y, isInit, isFin);
      groupToMinState.set(root, newState.id);
      gIdx++;
    }

    // Add transitions for minimized DFA
    for (const [root, members] of groups.entries()) {
      const representative = members[0];
      const fromMinId = groupToMinState.get(root);

      for (const sym of alphabet) {
        const nextId = getNextState(representative.id, sym);
        if (nextId !== null && idToIndex.has(nextId)) {
          const nextRoot = find(idToIndex.get(nextId));
          const toMinId = groupToMinState.get(nextRoot);
          if (fromMinId !== undefined && toMinId !== undefined) {
            minDfa.addTransition(fromMinId, toMinId, [sym]);
          }
        }
      }
    }

    return {
      minDfa,
      steps,
      stateList,
      table
    };
  }

  // ===================================================================
  // 3. FA -> REGULAR EXPRESSION (State Elimination Method)
  // ===================================================================
  static faToRegex(automaton) {
    const states = Array.from(automaton.states.values());
    if (states.length === 0) return { regex: '∅', steps: ['No states in automaton.'] };

    const initial = automaton.getInitialState();
    if (!initial) throw new Error('Automaton has no initial state.');

    const finals = automaton.getFinalStates();
    if (finals.length === 0) return { regex: '∅', steps: ['Automaton has no final states (accepts nothing).'] };

    const steps = [];

    // Helper functions for regex expressions
    function simplifyUnion(r1, r2) {
      if (r1 === '∅') return r2;
      if (r2 === '∅') return r1;
      if (r1 === r2) return r1;
      return `${r1}+${r2}`;
    }

    function simplifyConcat(r1, r2) {
      if (r1 === '∅' || r2 === '∅') return '∅';
      if (r1 === 'ε') return r2;
      if (r2 === 'ε') return r1;
      const p1 = r1.includes('+') ? `(${r1})` : r1;
      const p2 = r2.includes('+') ? `(${r2})` : r2;
      return `${p1}${p2}`;
    }

    function simplifyStar(r) {
      if (r === '∅' || r === 'ε') return 'ε';
      if (r.endsWith('*')) return r;
      if (r.length === 1) return `${r}*`;
      return `(${r})*`;
    }

    // Generalized NFA transition matrix: map of (i, j) -> regex string
    const R = new Map();
    function getKey(u, v) { return `${u}->${v}`; }
    function getR(u, v) { return R.get(getKey(u, v)) || '∅'; }
    function setR(u, v, expr) {
      if (expr !== '∅') R.set(getKey(u, v), expr);
      else R.delete(getKey(u, v));
    }

    // Initialize with direct transitions
    for (const t of automaton.transitions) {
      const fromName = automaton.getState(t.from)?.name;
      const toName = automaton.getState(t.to)?.name;
      if (!fromName || !toName) continue;

      let symExpr = t.symbols.join('+');
      const existing = getR(fromName, toName);
      setR(fromName, toName, simplifyUnion(existing, symExpr));
    }

    // Step 1: Add new initial state S and new final state F
    const S = 'S_start';
    const F = 'F_accept';
    setR(S, initial.name, 'ε');

    for (const f of finals) {
      const existing = getR(f.name, F);
      setR(f.name, F, simplifyUnion(existing, 'ε'));
    }

    steps.push(`Created single Start State (${S}) &rarr; ${initial.name} and Final State (${F}) from [${finals.map(f => f.name).join(', ')}].`);

    // Eliminate all original states one by one
    const statesToEliminate = states.map(s => s.name);

    for (const k of statesToEliminate) {
      const R_kk = getR(k, k);
      const star_R_kk = simplifyStar(R_kk);

      // Find all in-states and out-states connected to k
      const inStates = new Set();
      const outStates = new Set();

      for (const [key, expr] of R.entries()) {
        const [u, v] = key.split('->');
        if (v === k && u !== k && expr !== '∅') inStates.add(u);
        if (u === k && v !== k && expr !== '∅') outStates.add(v);
      }

      for (const p of inStates) {
        for (const q of outStates) {
          const R_pk = getR(p, k);
          const R_kq = getR(k, q);
          const R_pq = getR(p, q);

          const bypass = simplifyConcat(simplifyConcat(R_pk, star_R_kk), R_kq);
          const newExpr = simplifyUnion(R_pq, bypass);
          setR(p, q, newExpr);
        }
      }

      // Remove all transitions connected to k
      for (const key of Array.from(R.keys())) {
        const [u, v] = key.split('->');
        if (u === k || v === k) R.delete(key);
      }

      steps.push(`Eliminated state <strong>${k}</strong>. Updated remaining direct paths.`);
    }

    const finalRegex = getR(S, F);
    steps.push(`Final expression from ${S} to ${F}: <code>${finalRegex}</code>`);

    return {
      regex: finalRegex,
      steps
    };
  }

  // ===================================================================
  // 4. REGEX -> ε-NFA (Thompson's Construction)
  // ===================================================================
  static regexToNfa(regex) {
    if (!regex || regex.trim() === '') {
      throw new Error('Please enter a valid regular expression.');
    }

    // Tokenizer & Parser with explicit concatenation '.' insertion
    function insertExplicitConcat(str) {
      let res = '';
      for (let i = 0; i < str.length; i++) {
        const c1 = str[i];
        res += c1;
        if (i + 1 < str.length) {
          const c2 = str[i + 1];
          // Conditions to insert concatenation dot
          const c1IsOperand = /[a-zA-Z0-9ε]|\*|\+|\)/.test(c1);
          const c2IsOperand = /[a-zA-Z0-9ε]|\(/.test(c2);
          if (c1IsOperand && c2IsOperand) {
            res += '.';
          }
        }
      }
      return res;
    }

    // Shunting-Yard to Postfix
    const precedence = { '*': 3, '+': 3, '?': 3, '.': 2, '|': 1 };
    function toPostfix(infix) {
      let postfix = '';
      const opStack = [];

      for (let i = 0; i < infix.length; i++) {
        const char = infix[i];
        if (/[a-zA-Z0-9ε]/.test(char)) {
          postfix += char;
        } else if (char === '(') {
          opStack.push(char);
        } else if (char === ')') {
          while (opStack.length > 0 && opStack[opStack.length - 1] !== '(') {
            postfix += opStack.pop();
          }
          opStack.pop(); // Pop '('
        } else if (precedence[char]) {
          while (
            opStack.length > 0 &&
            opStack[opStack.length - 1] !== '(' &&
            precedence[opStack[opStack.length - 1]] >= precedence[char]
          ) {
            postfix += opStack.pop();
          }
          opStack.push(char);
        }
      }

      while (opStack.length > 0) {
        postfix += opStack.pop();
      }
      return postfix;
    }

    const prepared = insertExplicitConcat(regex.replace(/\s+/g, ''));
    const postfix = toPostfix(prepared);

    // Thompson's Construction Fragment: { startId, endId }
    const nfa = new Automaton('FA');
    let stateCounter = 0;

    function createState() {
      return nfa.addState(`q${stateCounter++}`, 0, 0);
    }

    const fragmentStack = [];

    for (let i = 0; i < postfix.length; i++) {
      const token = postfix[i];

      if (/[a-zA-Z0-9ε]/.test(token)) {
        // Base character block: s0 --token--> s1
        const s = createState();
        const e = createState();
        nfa.addTransition(s.id, e.id, [token]);
        fragmentStack.push({ start: s.id, end: e.id });
      } else if (token === '.') {
        // Concatenation: f1.end --ε--> f2.start
        const f2 = fragmentStack.pop();
        const f1 = fragmentStack.pop();
        if (!f1 || !f2) continue;

        nfa.addTransition(f1.end, f2.start, ['ε']);
        fragmentStack.push({ start: f1.start, end: f2.end });
      } else if (token === '|') {
        // Union: new S --ε--> f1, f2; f1, f2 --ε--> new E
        const f2 = fragmentStack.pop();
        const f1 = fragmentStack.pop();
        if (!f1 || !f2) continue;

        const s = createState();
        const e = createState();

        nfa.addTransition(s.id, f1.start, ['ε']);
        nfa.addTransition(s.id, f2.start, ['ε']);
        nfa.addTransition(f1.end, e.id, ['ε']);
        nfa.addTransition(f2.end, e.id, ['ε']);

        fragmentStack.push({ start: s.id, end: e.id });
      } else if (token === '*') {
        // Kleene star
        const f = fragmentStack.pop();
        if (!f) continue;

        const s = createState();
        const e = createState();

        nfa.addTransition(s.id, f.start, ['ε']);
        nfa.addTransition(s.id, e.id, ['ε']);
        nfa.addTransition(f.end, f.start, ['ε']);
        nfa.addTransition(f.end, e.id, ['ε']);

        fragmentStack.push({ start: s.id, end: e.id });
      }
    }

    const finalFragment = fragmentStack.pop();
    if (!finalFragment) throw new Error('Failed to parse regular expression.');

    // Mark Initial and Final
    const startNode = nfa.getState(finalFragment.start);
    const endNode = nfa.getState(finalFragment.end);
    if (startNode) startNode.isInitial = true;
    if (endNode) endNode.isFinal = true;

    // Distribute state positions cleanly along horizontal stages
    const statesList = Array.from(nfa.states.values());
    const count = statesList.length;
    const spacingX = Math.min(80, 800 / (count || 1));

    statesList.forEach((s, idx) => {
      s.x = Math.round(80 + idx * spacingX);
      s.y = Math.round(240 + ((idx % 2 === 0) ? -35 : 35));
    });

    return nfa;
  }

  // ===================================================================
  // 5. REGULAR GRAMMAR <-> FINITE AUTOMATON
  // ===================================================================
  static grammarToFa(grammarText) {
    const lines = grammarText.split('\n').map(l => l.trim()).filter(Boolean);
    const nfa = new Automaton('FA');
    const stateMap = new Map(); // Variable name -> State object

    let startStateName = null;

    // First pass: identify variables
    for (const line of lines) {
      const parts = line.split('->').map(p => p.trim());
      if (parts.length === 2) {
        const lhs = parts[0];
        if (!startStateName) startStateName = lhs;
        if (!stateMap.has(lhs)) {
          const s = nfa.addState(lhs, 0, 0, lhs === startStateName, false);
          stateMap.set(lhs, s);
        }
      }
    }

    // Dedicated final state for terminal-only productions (e.g. A -> 0)
    let finalState = null;

    for (const line of lines) {
      const parts = line.split('->').map(p => p.trim());
      if (parts.length !== 2) continue;
      const lhs = parts[0];
      const fromState = stateMap.get(lhs);
      const rhsAlts = parts[1].split('|').map(a => a.trim());

      for (const alt of rhsAlts) {
        if (alt === 'ε' || alt === 'e' || alt === 'λ') {
          // A -> ε makes A a final state
          fromState.isFinal = true;
        } else if (alt.length === 1) {
          // Terminal only: A -> a => A --a--> FinalState
          if (!finalState) {
            finalState = nfa.addState('q_accept', 0, 0, false, true);
          }
          nfa.addTransition(fromState.id, finalState.id, [alt]);
        } else {
          // A -> aB (terminal followed by variable)
          const terminal = alt[0];
          const varName = alt.slice(1);
          if (!stateMap.has(varName)) {
            const newS = nfa.addState(varName, 0, 0, false, false);
            stateMap.set(varName, newS);
          }
          const toState = stateMap.get(varName);
          nfa.addTransition(fromState.id, toState.id, [terminal]);
        }
      }
    }

    // Position states
    const states = Array.from(nfa.states.values());
    const angleStep = (2 * Math.PI) / states.length;
    states.forEach((s, idx) => {
      s.x = Math.round(360 + 160 * Math.cos(idx * angleStep));
      s.y = Math.round(240 + 160 * Math.sin(idx * angleStep));
    });

    return nfa;
  }

  static faToGrammar(automaton) {
    const states = Array.from(automaton.states.values());
    if (states.length === 0) return 'No states in automaton.';

    const initial = automaton.getInitialState();
    const productions = new Map(); // Variable -> Set of RHS strings

    // Ensure initial state appears first
    if (initial) productions.set(initial.name, new Set());

    for (const s of states) {
      if (!productions.has(s.name)) {
        productions.set(s.name, new Set());
      }
      if (s.isFinal) {
        productions.get(s.name).add('ε');
      }
    }

    for (const t of automaton.transitions) {
      const from = automaton.getState(t.from);
      const to = automaton.getState(t.to);
      if (!from || !to) continue;

      for (const sym of t.symbols) {
        if (to.isFinal && (sym !== 'ε' && sym !== 'e')) {
          // Production A -> a
          productions.get(from.name).add(sym);
        }
        // Production A -> aB
        productions.get(from.name).add(`${sym}${to.name}`);
      }
    }

    let result = '';
    for (const [varName, rhsSet] of productions.entries()) {
      if (rhsSet.size > 0) {
        result += `${varName} -> ${Array.from(rhsSet).join(' | ')}\n`;
      }
    }

    return result || 'No transitions to generate grammar.';
  }
}
