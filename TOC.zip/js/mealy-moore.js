/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Mealy and Moore Machines Engine & Simulator
 */

class MealyMooreEngine {
  constructor(automaton, mode = 'mealy') {
    this.automaton = automaton;
    this.mode = mode; // 'mealy' | 'moore'
    this.reset();
  }

  setMode(mode) {
    this.mode = mode;
    this.automaton.type = mode.toUpperCase();
    this.reset();
  }

  reset() {
    this.inputString = '';
    this.charIndex = 0;
    this.currentState = this.automaton.getInitialState();
    this.outputStream = [];
    this.stateStream = [];
    this.isFinished = false;

    if (this.currentState) {
      this.stateStream.push(this.currentState.name);
      if (this.mode === 'moore' && this.currentState.output !== undefined) {
        this.outputStream.push(this.currentState.output);
      }
    }
  }

  setInput(str) {
    this.inputString = str;
    this.reset();
  }

  step() {
    if (this.isFinished || !this.currentState) return null;

    if (this.charIndex >= this.inputString.length) {
      this.isFinished = true;
      return { finished: true, outputStream: [...this.outputStream] };
    }

    const char = this.inputString[this.charIndex];
    const outgoing = this.automaton.getTransitionsFrom(this.currentState.id);
    let matchedTrans = null;
    let nextState = null;
    let emittedChar = '';

    if (this.mode === 'mealy') {
      // Find transition with label "char/out"
      for (const t of outgoing) {
        for (const s of t.symbols) {
          const parts = s.split('/').map(p => p.trim());
          if (parts[0] === char) {
            matchedTrans = t;
            nextState = this.automaton.getState(t.to);
            emittedChar = parts[1] || '';
            break;
          }
        }
        if (matchedTrans) break;
      }
    } else {
      // Moore mode: transition has symbol "char", state has output
      for (const t of outgoing) {
        if (t.symbols.some(s => s.trim() === char)) {
          matchedTrans = t;
          nextState = this.automaton.getState(t.to);
          if (nextState) {
            emittedChar = nextState.output || '';
          }
          break;
        }
      }
    }

    if (!nextState) {
      this.isFinished = true;
      return { finished: true, error: `No transition from ${this.currentState.name} on input '${char}'` };
    }

    this.currentState = nextState;
    this.charIndex++;
    this.stateStream.push(nextState.name);
    this.outputStream.push(emittedChar);

    if (this.charIndex >= this.inputString.length) {
      this.isFinished = true;
    }

    return {
      finished: this.isFinished,
      charRead: char,
      emittedChar,
      currentState: this.currentState,
      traversedTransitionId: matchedTrans?.id,
      inputIndex: this.charIndex,
      outputStream: [...this.outputStream],
      stateStream: [...this.stateStream]
    };
  }

  // Generate Transition / Output Table
  generateTable() {
    const states = Array.from(this.automaton.states.values());
    if (states.length === 0) return '<p class="empty-hint">No states in machine.</p>';

    const alphabet = this.automaton.getAlphabet();
    let html = '<table class="clean-table">';

    if (this.mode === 'mealy') {
      html += '<thead><tr><th rowspan="2">Present State</th>';
      for (const sym of alphabet) {
        html += `<th colspan="2">Input = ${sym}</th>`;
      }
      html += '</tr><tr>';
      for (const sym of alphabet) {
        html += '<th>Next State</th><th>Output</th>';
      }
      html += '</tr></thead><tbody>';

      for (const s of states) {
        const initPrefix = s.isInitial ? '&rarr; ' : '';
        html += `<tr><td class="state-name">${initPrefix}${s.name}</td>`;

        const outgoing = this.automaton.getTransitionsFrom(s.id);
        for (const sym of alphabet) {
          let nextName = '-';
          let out = '-';

          for (const t of outgoing) {
            for (const symLabel of t.symbols) {
              const parts = symLabel.split('/').map(p => p.trim());
              if (parts[0] === sym) {
                const target = this.automaton.getState(t.to);
                nextName = target ? target.name : '-';
                out = parts[1] || '';
                break;
              }
            }
          }

          html += `<td>${nextName}</td><td>${out}</td>`;
        }
        html += '</tr>';
      }
    } else {
      // Moore table
      html += '<thead><tr><th>Present State</th>';
      for (const sym of alphabet) {
        html += `<th>Next State (x = ${sym})</th>`;
      }
      html += '<th>Output</th></tr></thead><tbody>';

      for (const s of states) {
        const initPrefix = s.isInitial ? '&rarr; ' : '';
        html += `<tr><td class="state-name">${initPrefix}${s.name}</td>`;

        const outgoing = this.automaton.getTransitionsFrom(s.id);
        for (const sym of alphabet) {
          let nextName = '-';
          for (const t of outgoing) {
            if (t.symbols.some(sl => sl.trim() === sym)) {
              const target = this.automaton.getState(t.to);
              nextName = target ? target.name : '-';
              break;
            }
          }
          html += `<td>${nextName}</td>`;
        }
        html += `<td><strong>${s.output || '-'}</strong></td></tr>`;
      }
    }

    html += '</tbody></table>';
    return html;
  }

  // Mealy <-> Moore Converter
  static convertMealyToMoore(mealy) {
    const moore = new Automaton('MOORE');
    const states = Array.from(mealy.states.values());
    const initial = mealy.getInitialState();
    if (!initial) throw new Error('Mealy machine has no initial state.');

    // For each state q, find all distinct outputs incoming to q
    const incomingOutputs = new Map(); // stateId -> Set of outputs
    for (const s of states) incomingOutputs.set(s.id, new Set());

    // Initial state default output
    incomingOutputs.get(initial.id).add('0');

    for (const t of mealy.transitions) {
      for (const s of t.symbols) {
        const parts = s.split('/').map(p => p.trim());
        const out = parts[1] || '0';
        incomingOutputs.get(t.to).add(out);
      }
    }

    // Create split Moore states q_out
    const newStatesMap = new Map(); // `${oldId}_${out}` -> new State
    let stateIdx = 0;

    for (const s of states) {
      const outputs = Array.from(incomingOutputs.get(s.id));
      if (outputs.length === 0) outputs.push('0');

      for (const out of outputs) {
        const isInit = (s.id === initial.id && out === '0');
        const newState = moore.addState(
          `${s.name}_${out}`,
          s.x + (outputs.length > 1 ? (out === '0' ? -25 : 25) : 0),
          s.y,
          isInit,
          false,
          out
        );
        newStatesMap.set(`${s.id}_${out}`, newState);
      }
    }

    // Connect transitions
    for (const s of states) {
      const outputs = Array.from(incomingOutputs.get(s.id));
      if (outputs.length === 0) outputs.push('0');

      for (const out of outputs) {
        const fromMooreState = newStatesMap.get(`${s.id}_${out}`);
        const outgoing = mealy.getTransitionsFrom(s.id);

        for (const t of outgoing) {
          for (const sym of t.symbols) {
            const parts = sym.split('/').map(p => p.trim());
            const inSym = parts[0];
            const targetOut = parts[1] || '0';

            const toMooreState = newStatesMap.get(`${t.to}_${targetOut}`);
            if (fromMooreState && toMooreState) {
              moore.addTransition(fromMooreState.id, toMooreState.id, [inSym]);
            }
          }
        }
      }
    }

    return moore;
  }

  static convertMooreToMealy(moore) {
    const mealy = new Automaton('MEALY');
    const oldToNew = new Map();

    for (const s of moore.states.values()) {
      const newState = mealy.addState(s.name, s.x, s.y, s.isInitial, s.isFinal);
      oldToNew.set(s.id, newState.id);
    }

    for (const t of moore.transitions) {
      const target = moore.getState(t.to);
      const output = target?.output || '0';

      const fromNew = oldToNew.get(t.from);
      const toNew = oldToNew.get(t.to);

      const mealySymbols = t.symbols.map(s => `${s.trim()}/${output}`);
      mealy.addTransition(fromNew, toNew, mealySymbols, t.curve);
    }

    return mealy;
  }
}
