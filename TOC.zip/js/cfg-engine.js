/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * CFG & Parsing Engine:
 * - FIRST & FOLLOW Sets
 * - LL(1) Parsing Table & Stack Simulation
 * - SLR(1) LR(0) Items Collection & Table
 * - Chomsky Normal Form (CNF) 5-Step Converter
 */

class CFGEngine {
  constructor(rawGrammarText) {
    this.rawText = rawGrammarText;
    this.parseGrammar(rawGrammarText);
  }

  isEpsilon(sym) {
    return sym === 'ε' || sym === 'e' || sym === 'λ' || sym === '';
  }

  parseGrammar(text) {
    this.productions = []; // Array of { lhs, rhs: [tokens] }
    this.nonTerminals = new Set();
    this.terminals = new Set();
    this.startSymbol = null;

    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

    for (const line of lines) {
      const parts = line.split('->').map(p => p.trim());
      if (parts.length !== 2) continue;
      const lhs = parts[0];
      this.nonTerminals.add(lhs);
      if (!this.startSymbol) this.startSymbol = lhs;

      const alts = parts[1].split('|').map(a => a.trim());
      for (const alt of alts) {
        // Tokenize RHS into symbols (supports words like 'id' or individual chars)
        const tokens = this.tokenizeRHS(alt);
        this.productions.push({ lhs, rhs: tokens, rawRhs: alt });

        for (const tok of tokens) {
          if (!this.isNonTerminal(tok) && !this.isEpsilon(tok)) {
            this.terminals.add(tok);
          }
        }
      }
    }
  }

  isNonTerminal(sym) {
    // Non-terminals are uppercase or uppercase with prime, e.g. E, E', T, T'
    return /^[A-Z][']?$/.test(sym);
  }

  tokenizeRHS(rhsStr) {
    if (this.isEpsilon(rhsStr)) return ['ε'];
    const tokens = [];
    const parts = rhsStr.split(/\s+/).filter(Boolean);

    // If spaces were provided, respect token boundary
    if (parts.length > 1 || parts.some(p => p === 'id')) {
      return parts;
    }

    // Otherwise split by characters while handling primes (e.g. E')
    let i = 0;
    while (i < rhsStr.length) {
      let tok = rhsStr[i];
      if (i + 1 < rhsStr.length && rhsStr[i + 1] === "'") {
        tok += "'";
        i++;
      }
      tokens.push(tok);
      i++;
    }
    return tokens;
  }

  // ===================================================================
  // 1. FIRST and FOLLOW SETS
  // ===================================================================
  computeFirstSets() {
    const first = new Map();
    for (const nt of this.nonTerminals) first.set(nt, new Set());
    for (const t of this.terminals) first.set(t, new Set([t]));
    first.set('ε', new Set(['ε']));

    let changed = true;
    while (changed) {
      changed = false;

      for (const prod of this.productions) {
        const lhs = prod.lhs;
        const rhs = prod.rhs;
        const lhsFirst = first.get(lhs);

        if (rhs.length === 1 && this.isEpsilon(rhs[0])) {
          if (!lhsFirst.has('ε')) {
            lhsFirst.add('ε');
            changed = true;
          }
          continue;
        }

        let allCanBeEpsilon = true;
        for (const symbol of rhs) {
          const symFirst = first.get(symbol) || new Set([symbol]);

          for (const item of symFirst) {
            if (item !== 'ε' && !lhsFirst.has(item)) {
              lhsFirst.add(item);
              changed = true;
            }
          }

          if (!symFirst.has('ε')) {
            allCanBeEpsilon = false;
            break;
          }
        }

        if (allCanBeEpsilon && !lhsFirst.has('ε')) {
          lhsFirst.add('ε');
          changed = true;
        }
      }
    }

    this.firstSets = first;
    return first;
  }

  getFirstOfString(tokens) {
    const res = new Set();
    if (!this.firstSets) this.computeFirstSets();

    if (tokens.length === 0) {
      res.add('ε');
      return res;
    }

    let allEpsilon = true;
    for (const tok of tokens) {
      const tokFirst = this.firstSets.get(tok) || new Set([tok]);
      for (const item of tokFirst) {
        if (item !== 'ε') res.add(item);
      }
      if (!tokFirst.has('ε')) {
        allEpsilon = false;
        break;
      }
    }

    if (allEpsilon) res.add('ε');
    return res;
  }

  computeFollowSets() {
    if (!this.firstSets) this.computeFirstSets();

    const follow = new Map();
    for (const nt of this.nonTerminals) follow.set(nt, new Set());

    // Rule 1: Add '$' to start symbol
    if (this.startSymbol) {
      follow.get(this.startSymbol).add('$');
    }

    let changed = true;
    while (changed) {
      changed = false;

      for (const prod of this.productions) {
        const lhs = prod.lhs;
        const rhs = prod.rhs;

        for (let i = 0; i < rhs.length; i++) {
          const B = rhs[i];
          if (!this.nonTerminals.has(B)) continue;

          const beta = rhs.slice(i + 1);
          const firstBeta = this.getFirstOfString(beta);
          const followB = follow.get(B);

          // Rule 2: Everything in FIRST(beta) except ε goes into FOLLOW(B)
          for (const item of firstBeta) {
            if (item !== 'ε' && !followB.has(item)) {
              followB.add(item);
              changed = true;
            }
          }

          // Rule 3: If beta =>* ε (or beta is empty), everything in FOLLOW(A) goes into FOLLOW(B)
          if (firstBeta.has('ε')) {
            const followA = follow.get(lhs);
            for (const item of followA) {
              if (!followB.has(item)) {
                followB.add(item);
                changed = true;
              }
            }
          }
        }
      }
    }

    this.followSets = follow;
    return follow;
  }

  // ===================================================================
  // 2. LL(1) PARSER & TABLE
  // ===================================================================
  buildLL1Table() {
    this.computeFirstSets();
    this.computeFollowSets();

    const table = new Map(); // nt -> Map(terminal -> [productions])
    const terminalsWithEnd = [...Array.from(this.terminals).sort(), '$'];

    for (const nt of this.nonTerminals) {
      const row = new Map();
      for (const t of terminalsWithEnd) row.set(t, []);
      table.set(nt, row);
    }

    let hasConflict = false;
    const conflicts = [];

    for (let pIdx = 0; pIdx < this.productions.length; pIdx++) {
      const prod = this.productions[pIdx];
      const A = prod.lhs;
      const alpha = prod.rhs;
      const firstAlpha = this.getFirstOfString(alpha);

      for (const a of firstAlpha) {
        if (a !== 'ε') {
          const cell = table.get(A).get(a);
          if (cell) {
            cell.push(prod);
            if (cell.length > 1) {
              hasConflict = true;
              conflicts.push(`Conflict at M[${A}, ${a}]`);
            }
          }
        }
      }

      if (firstAlpha.has('ε')) {
        const followA = this.followSets.get(A);
        for (const b of followA) {
          const cell = table.get(A).get(b);
          if (cell) {
            if (!cell.includes(prod)) {
              cell.push(prod);
              if (cell.length > 1) {
                hasConflict = true;
                conflicts.push(`Conflict at M[${A}, ${b}]`);
              }
            }
          }
        }
      }
    }

    this.ll1Table = table;
    this.isLL1 = !hasConflict;
    this.ll1Conflicts = conflicts;

    return { table, isLL1: !hasConflict, conflicts };
  }

  simulateLL1Parse(inputTokensString) {
    if (!this.ll1Table) this.buildLL1Table();
    if (!this.isLL1) {
      return { success: false, error: 'Grammar is not LL(1). Cannot parse deterministically.' };
    }

    const inputTokens = inputTokensString.trim().split(/\s+/).filter(Boolean);
    inputTokens.push('$');

    const stack = ['$', this.startSymbol];
    let ip = 0;
    const trace = [];

    while (stack.length > 0) {
      const X = stack[stack.length - 1];
      const a = inputTokens[ip];

      const stackView = stack.slice().reverse().join(' ');
      const inputView = inputTokens.slice(ip).join(' ');

      if (X === a) {
        if (X === '$') {
          trace.push({ stack: stackView, input: inputView, action: 'Accept ✓' });
          return { success: true, trace };
        }
        stack.pop();
        ip++;
        trace.push({ stack: stackView, input: inputView, action: `Match terminal '${a}'` });
      } else if (!this.isNonTerminal(X)) {
        trace.push({ stack: stackView, input: inputView, action: `Error: Expected terminal '${X}', found '${a}'` });
        return { success: false, trace, error: `Mismatch: expected ${X}, got ${a}` };
      } else {
        const cell = this.ll1Table.get(X)?.get(a);
        if (!cell || cell.length === 0) {
          trace.push({ stack: stackView, input: inputView, action: `Error: No rule in M[${X}, ${a}]` });
          return { success: false, trace, error: `No rule in M[${X}, ${a}]` };
        }

        const prod = cell[0];
        stack.pop();

        if (!(prod.rhs.length === 1 && this.isEpsilon(prod.rhs[0]))) {
          // Push RHS in reverse
          for (let i = prod.rhs.length - 1; i >= 0; i--) {
            stack.push(prod.rhs[i]);
          }
        }

        trace.push({ stack: stackView, input: inputView, action: `Output ${prod.lhs} &rarr; ${prod.rawRhs}` });
      }
    }

    return { success: false, trace, error: 'Unexpected end of parsing stack.' };
  }

  // ===================================================================
  // 3. SLR(1) LR(0) ITEMS & PARSER
  // ===================================================================
  buildSLR1Table() {
    this.computeFirstSets();
    this.computeFollowSets();

    // Augmented start production S' -> S
    const augStart = `${this.startSymbol}'`;
    const augProds = [
      { id: 0, lhs: augStart, rhs: [this.startSymbol] },
      ...this.productions.map((p, idx) => ({ id: idx + 1, lhs: p.lhs, rhs: p.rhs, rawRhs: p.rawRhs }))
    ];

    // LR(0) Item: { prodId, dotPos }
    function itemToString(item) {
      const p = augProds[item.prodId];
      const r = [...p.rhs];
      r.splice(item.dotPos, 0, '•');
      return `${p.lhs} -> ${r.join(' ')}`;
    }

    function itemEquals(it1, it2) {
      return it1.prodId === it2.prodId && it1.dotPos === it2.dotPos;
    }

    const self = this;
    function closure(items) {
      const set = [...items];
      let added = true;

      while (added) {
        added = false;
        for (const item of [...set]) {
          const p = augProds[item.prodId];
          if (item.dotPos < p.rhs.length) {
            const B = p.rhs[item.dotPos];
            if (self.nonTerminals.has(B)) {
              for (const otherP of augProds) {
                if (otherP.lhs === B) {
                  const newItem = { prodId: otherP.id, dotPos: 0 };
                  if (!set.some(it => itemEquals(it, newItem))) {
                    set.push(newItem);
                    added = true;
                  }
                }
              }
            }
          }
        }
      }
      return set;
    }

    function goto(items, symbol) {
      const moved = [];
      for (const item of items) {
        const p = augProds[item.prodId];
        if (item.dotPos < p.rhs.length && p.rhs[item.dotPos] === symbol) {
          moved.push({ prodId: item.prodId, dotPos: item.dotPos + 1 });
        }
      }
      return closure(moved);
    }

    function stateKey(items) {
      return items.map(it => `${it.prodId}:${it.dotPos}`).sort().join(',');
    }

    // Build Canonical Collection of Sets of LR(0) Items
    const states = [closure([{ prodId: 0, dotPos: 0 }])];
    const stateKeys = new Map();
    stateKeys.set(stateKey(states[0]), 0);

    const grammarSymbols = [...Array.from(this.terminals), ...Array.from(this.nonTerminals)];
    const transitions = []; // { from, symbol, to }

    let queue = [0];
    while (queue.length > 0) {
      const currIdx = queue.shift();
      const currItems = states[currIdx];

      for (const X of grammarSymbols) {
        const nextItems = goto(currItems, X);
        if (nextItems.length > 0) {
          const k = stateKey(nextItems);
          let nextIdx;
          if (!stateKeys.has(k)) {
            nextIdx = states.length;
            states.push(nextItems);
            stateKeys.set(k, nextIdx);
            queue.push(nextIdx);
          } else {
            nextIdx = stateKeys.get(k);
          }
          transitions.push({ from: currIdx, symbol: X, to: nextIdx });
        }
      }
    }

    // Build ACTION and GOTO tables
    const actionTable = Array.from({ length: states.length }, () => ({}));
    const gotoTable = Array.from({ length: states.length }, () => ({}));
    let conflicts = [];

    // Shifts and Gotos
    for (const tr of transitions) {
      if (this.terminals.has(tr.symbol)) {
        actionTable[tr.from][tr.symbol] = `s${tr.to}`;
      } else if (this.nonTerminals.has(tr.symbol)) {
        gotoTable[tr.from][tr.symbol] = tr.to;
      }
    }

    // Reduces
    for (let i = 0; i < states.length; i++) {
      for (const item of states[i]) {
        const p = augProds[item.prodId];
        if (item.dotPos === p.rhs.length || (p.rhs.length === 1 && this.isEpsilon(p.rhs[0]))) {
          if (p.id === 0) {
            actionTable[i]['$'] = 'acc';
          } else {
            const followLhs = this.followSets.get(p.lhs) || new Set(['$']);
            for (const a of followLhs) {
              if (actionTable[i][a]) {
                conflicts.push(`Conflict in state I${i} on symbol '${a}': ${actionTable[i][a]} vs r${p.id}`);
              } else {
                actionTable[i][a] = `r${p.id}`;
              }
            }
          }
        }
      }
    }

    return {
      states,
      augProds,
      actionTable,
      gotoTable,
      conflicts,
      isSLR1: conflicts.length === 0,
      itemToString
    };
  }

  // ===================================================================
  // 4. CHOMSKY NORMAL FORM (CNF) 5-STEP CONVERTER
  // ===================================================================
  static convertToCNF(cfgText) {
    const steps = [];

    // Parse initial rules
    let rules = []; // { lhs, rhs: [tokens] }
    const lines = cfgText.split('\n').map(l => l.trim()).filter(Boolean);
    let startSym = null;

    for (const line of lines) {
      const parts = line.split('->').map(p => p.trim());
      if (parts.length !== 2) continue;
      const lhs = parts[0];
      if (!startSym) startSym = lhs;
      const alts = parts[1].split('|').map(a => a.trim());
      for (const a of alts) {
        rules.push({ lhs, rhs: a.split(/\s+/).filter(Boolean) });
      }
    }

    function formatGrammar(rList) {
      const grouped = new Map();
      for (const r of rList) {
        if (!grouped.has(r.lhs)) grouped.set(r.lhs, []);
        grouped.get(r.lhs).push(r.rhs.join(' '));
      }
      return Array.from(grouped.entries())
        .map(([lhs, alts]) => `${lhs} -> ${alts.join(' | ')}`)
        .join('\n');
    }

    steps.push({
      title: 'Original Grammar',
      content: formatGrammar(rules)
    });

    // Step 1: Start Symbol Simplification S0 -> S
    const s0 = 'S₀';
    rules.unshift({ lhs: s0, rhs: [startSym] });
    steps.push({
      title: 'Step 1: Introduce New Start Symbol',
      desc: `Created new start symbol ${s0} &rarr; ${startSym}`,
      content: formatGrammar(rules)
    });

    // Step 2: Eliminate Epsilon Productions A -> ε
    const nullable = new Set();
    let nChanged = true;
    while (nChanged) {
      nChanged = false;
      for (const r of rules) {
        if (r.rhs.length === 1 && (r.rhs[0] === 'ε' || r.rhs[0] === 'e')) {
          if (!nullable.has(r.lhs)) {
            nullable.add(r.lhs);
            nChanged = true;
          }
        } else if (r.rhs.every(sym => nullable.has(sym))) {
          if (!nullable.has(r.lhs)) {
            nullable.add(r.lhs);
            nChanged = true;
          }
        }
      }
    }

    // Expand rules omitting combinations of nullable variables
    const noEpsRules = [];
    for (const r of rules) {
      if (r.rhs.length === 1 && (r.rhs[0] === 'ε' || r.rhs[0] === 'e')) continue;

      function generateSubsets(tokens) {
        if (tokens.length === 0) return [[]];
        const first = tokens[0];
        const restSubsets = generateSubsets(tokens.slice(1));
        const res = [];
        for (const sub of restSubsets) {
          res.push([first, ...sub]);
          if (nullable.has(first)) {
            res.push(sub);
          }
        }
        return res;
      }

      const combos = generateSubsets(r.rhs);
      for (const combo of combos) {
        if (combo.length > 0) {
          const exists = noEpsRules.some(er => er.lhs === r.lhs && er.rhs.join(' ') === combo.join(' '));
          if (!exists) {
            noEpsRules.push({ lhs: r.lhs, rhs: combo });
          }
        }
      }
    }

    rules = noEpsRules;
    steps.push({
      title: 'Step 2: Eliminate Nullable (ε) Productions',
      desc: `Identified nullable variables: { ${Array.from(nullable).join(', ') || 'none'} }`,
      content: formatGrammar(rules)
    });

    // Step 3: Eliminate Unit Productions A -> B
    let unitChanged = true;
    while (unitChanged) {
      unitChanged = false;
      const nextRules = [];

      for (const r of rules) {
        if (r.rhs.length === 1 && /^[A-Z₀']$/.test(r.rhs[0]) && r.lhs !== r.rhs[0]) {
          const targetNT = r.rhs[0];
          unitChanged = true;
          // Substitute all productions of targetNT into r.lhs
          for (const other of rules) {
            if (other.lhs === targetNT) {
              const already = nextRules.some(nr => nr.lhs === r.lhs && nr.rhs.join(' ') === other.rhs.join(' '));
              if (!already) {
                nextRules.push({ lhs: r.lhs, rhs: [...other.rhs] });
              }
            }
          }
        } else {
          nextRules.push(r);
        }
      }
      rules = nextRules;
    }

    steps.push({
      title: 'Step 3: Eliminate Unit Productions (A &rarr; B)',
      desc: 'Substituted non-unit targets for single variable rules.',
      content: formatGrammar(rules)
    });

    // Step 4 & 5: Replace terminals in long rules & binarize
    let varCounter = 1;
    const termMap = new Map(); // 'a' -> 'T_a'
    const newRules = [];

    // Step 4: Replace terminals in rules of length >= 2
    for (const r of rules) {
      if (r.rhs.length >= 2) {
        const newRhs = [];
        for (const tok of r.rhs) {
          if (!/^[A-Z₀']/.test(tok)) {
            if (!termMap.has(tok)) {
              const tVar = `T_${tok}`;
              termMap.set(tok, tVar);
              newRules.push({ lhs: tVar, rhs: [tok] });
            }
            newRhs.push(termMap.get(tok));
          } else {
            newRhs.push(tok);
          }
        }
        r.rhs = newRhs;
      }
    }

    // Step 5: Binarize rules with length > 2
    const finalRules = [...newRules];
    for (const r of rules) {
      if (r.rhs.length <= 2) {
        finalRules.push(r);
      } else {
        let currentLhs = r.lhs;
        for (let i = 0; i < r.rhs.length - 2; i++) {
          const newVar = `C_${varCounter++}`;
          finalRules.push({ lhs: currentLhs, rhs: [r.rhs[i], newVar] });
          currentLhs = newVar;
        }
        finalRules.push({ lhs: currentLhs, rhs: [r.rhs[r.rhs.length - 2], r.rhs[r.rhs.length - 1]] });
      }
    }

    steps.push({
      title: 'Step 4 & 5: Binarization & Chomsky Normal Form (CNF)',
      desc: 'Replaced terminals in composite rules and split into binary productions (A &rarr; BC or A &rarr; a).',
      content: formatGrammar(finalRules)
    });

    return { steps, cnfGrammar: formatGrammar(finalRules) };
  }
}
