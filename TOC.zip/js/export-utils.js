/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Export Utilities: PNG Export, JSON Save/Load, and Toast Notifications
 */

class ExportUtils {
  // Show Toast Notification
  static showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = 'ℹ️';
    if (type === 'success') icon = '✓';
    else if (type === 'error') icon = '✕';

    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  // Export Canvas as PNG
  static exportCanvasAsPNG(canvas, fileName = 'theory_of_computation_automaton.png') {
    // Create an off-screen canvas to render with crisp background and watermark
    const offCanvas = document.createElement('canvas');
    offCanvas.width = canvas.width;
    offCanvas.height = canvas.height;
    const ctx = offCanvas.getContext('2d');

    // Background
    const isDark = document.body.classList.contains('dark-theme');
    ctx.fillStyle = isDark ? '#0b0f19' : '#f8fafc';
    ctx.fillRect(0, 0, offCanvas.width, offCanvas.height);

    // Draw original canvas
    ctx.drawImage(canvas, 0, 0);

    // Watermark
    ctx.font = '600 13px "Inter", sans-serif';
    ctx.fillStyle = isDark ? 'rgba(56, 189, 248, 0.7)' : 'rgba(2, 132, 199, 0.7)';
    ctx.textAlign = 'right';
    ctx.fillText('Theory of Computation Studio • Developed by Gururaj Surampalli', offCanvas.width - 20, offCanvas.height - 18);

    // Trigger download
    const link = document.createElement('a');
    link.download = fileName;
    link.href = offCanvas.toDataURL('image/png');
    link.click();

    ExportUtils.showToast('Automaton exported as PNG successfully!', 'success');
  }

  // Save Automaton to JSON
  static saveToJSON(automaton, fileName = 'automaton.json') {
    const jsonStr = JSON.stringify(automaton.toJSON(), null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.download = fileName;
    link.href = url;
    link.click();

    URL.revokeObjectURL(url);
    ExportUtils.showToast('Automaton saved as JSON.', 'success');
  }

  // Load Automaton from JSON
  static loadFromJSON(file, callback) {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        if (!data.states || !data.transitions) {
          throw new Error('Invalid automaton JSON structure');
        }
        callback(data);
        ExportUtils.showToast('Automaton loaded successfully!', 'success');
      } catch (err) {
        ExportUtils.showToast(`Error loading JSON: ${err.message}`, 'error');
      }
    };
    reader.readAsText(file);
  }
}
