/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Library of Pre-Built Presets and Classic TOC Examples
 */

const TOCPresets = {
  // ===================================================================
  // FINITE AUTOMATA PRESETS
  // ===================================================================
  fa: {
    ends_with_01: {
      name: 'DFA: Strings Ending with "01"',
      description: 'Accepts all binary strings ending with the substring 01.',
      defaultInput: '1001',
      batchTests: ['01', '101', '11001', '0', '1', '10', '00'],
      data: {
        type: 'FA',
        states: [
          { id: 0, name: 'q0', x: 180, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 360, y: 240, isInitial: false, isFinal: false },
          { id: 2, name: 'q2', x: 540, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['1'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['0'], curve: 0 },
          { id: 2, from: 1, to: 1, symbols: ['0'], curve: 0 },
          { id: 3, from: 1, to: 2, symbols: ['1'], curve: 0 },
          { id: 4, from: 2, to: 1, symbols: ['0'], curve: 40 },
          { id: 5, from: 2, to: 0, symbols: ['1'], curve: -50 }
        ]
      }
    },

    even_zeros_even_ones: {
      name: 'DFA: Even 0s & Even 1s',
      description: 'Classic 4-state DFA accepting strings with an even number of 0s and an even number of 1s.',
      defaultInput: '0011',
      batchTests: ['0011', '0101', '1100', '01', '111', '000', 'ε'],
      data: {
        type: 'FA',
        states: [
          { id: 0, name: 'q_ee', x: 240, y: 160, isInitial: true, isFinal: true },
          { id: 1, name: 'q_oe', x: 440, y: 160, isInitial: false, isFinal: false },
          { id: 2, name: 'q_eo', x: 240, y: 340, isInitial: false, isFinal: false },
          { id: 3, name: 'q_oo', x: 440, y: 340, isInitial: false, isFinal: false }
        ],
        transitions: [
          { id: 0, from: 0, to: 1, symbols: ['0'], curve: 25 },
          { id: 1, from: 1, to: 0, symbols: ['0'], curve: 25 },
          { id: 2, from: 0, to: 2, symbols: ['1'], curve: 25 },
          { id: 3, return: 0, from: 2, to: 0, symbols: ['1'], curve: 25 },
          { id: 4, from: 1, to: 3, symbols: ['1'], curve: 25 },
          { id: 5, from: 3, to: 1, symbols: ['1'], curve: 25 },
          { id: 6, from: 2, to: 3, symbols: ['0'], curve: 25 },
          { id: 7, from: 3, to: 2, symbols: ['0'], curve: 25 }
        ]
      }
    },

    divisible_by_3: {
      name: 'DFA: Binary Numbers Divisible by 3',
      description: 'Accepts binary representations of integers divisible by 3 (q0: mod 0, q1: mod 1, q2: mod 2).',
      defaultInput: '110',
      batchTests: ['0', '11', '110', '1001', '1100', '1', '10', '101'],
      data: {
        type: 'FA',
        states: [
          { id: 0, name: 'q0', x: 200, y: 220, isInitial: true, isFinal: true },
          { id: 1, name: 'q1', x: 380, y: 140, isInitial: false, isFinal: false },
          { id: 2, name: 'q2', x: 380, y: 300, isInitial: false, isFinal: false }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['0'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['1'], curve: 25 },
          { id: 2, from: 1, to: 2, symbols: ['0'], curve: 25 },
          { id: 3, from: 1, to: 0, symbols: ['1'], curve: 25 },
          { id: 4, from: 2, to: 1, symbols: ['1'], curve: 25 },
          { id: 5, from: 2, to: 2, symbols: ['0'], curve: 0 }
        ]
      }
    },

    nfa_abb: {
      name: 'NFA: (a+b)*abb',
      description: 'Non-deterministic automaton recognizing all strings containing "abb" at the end.',
      defaultInput: 'ababb',
      batchTests: ['abb', 'aabb', 'babb', 'ab', 'a', 'b', 'abba'],
      data: {
        type: 'FA',
        states: [
          { id: 0, name: 'q0', x: 180, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 320, y: 240, isInitial: false, isFinal: false },
          { id: 2, name: 'q2', x: 460, y: 240, isInitial: false, isFinal: false },
          { id: 3, name: 'q3', x: 600, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['a', 'b'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['a'], curve: 0 },
          { id: 2, from: 1, to: 2, symbols: ['b'], curve: 0 },
          { id: 3, from: 2, to: 3, symbols: ['b'], curve: 0 }
        ]
      }
    },

    epsilon_nfa_example: {
      name: 'ε-NFA: (01)* + (10)*',
      description: 'Epsilon-NFA taking union of two periodic alternating languages.',
      defaultInput: '0101',
      batchTests: ['01', '0101', '10', '1010', 'ε', '00', '11'],
      data: {
        type: 'FA',
        states: [
          { id: 0, name: 'q_start', x: 140, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 280, y: 150, isInitial: false, isFinal: true },
          { id: 2, name: 'q2', x: 420, y: 150, isInitial: false, isFinal: false },
          { id: 3, name: 'q3', x: 280, y: 330, isInitial: false, isFinal: true },
          { id: 4, name: 'q4', x: 420, y: 330, isInitial: false, isFinal: false }
        ],
        transitions: [
          { id: 0, from: 0, to: 1, symbols: ['ε'], curve: 0 },
          { id: 1, from: 0, to: 3, symbols: ['ε'], curve: 0 },
          { id: 2, from: 1, to: 2, symbols: ['0'], curve: 25 },
          { id: 3, from: 2, to: 1, symbols: ['1'], curve: 25 },
          { id: 4, from: 3, to: 4, symbols: ['1'], curve: 25 },
          { id: 5, from: 4, to: 3, symbols: ['0'], curve: 25 }
        ]
      }
    }
  },

  // ===================================================================
  // TRANSDUCERS (MEALY & MOORE)
  // ===================================================================
  transducers: {
    mealy_ones_comp: {
      name: "Mealy 1's Complement",
      mode: 'mealy',
      defaultInput: '10110',
      data: {
        type: 'MEALY',
        states: [
          { id: 0, name: 'q0', x: 300, y: 200, isInitial: true, isFinal: false }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['0/1', '1/0'], curve: 0 }
        ]
      }
    },

    mealy_twos_comp: {
      name: "Mealy 2's Complement",
      mode: 'mealy',
      defaultInput: '00100',
      data: {
        type: 'MEALY',
        states: [
          { id: 0, name: 'q0', x: 200, y: 200, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 420, y: 200, isInitial: false, isFinal: false }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['0/0'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['1/1'], curve: 0 },
          { id: 2, from: 1, to: 1, symbols: ['0/1', '1/0'], curve: 0 }
        ]
      }
    },

    moore_mod3: {
      name: 'Moore Modulo 3 Counter',
      mode: 'moore',
      defaultInput: '110',
      data: {
        type: 'MOORE',
        states: [
          { id: 0, name: 'q0', x: 200, y: 220, isInitial: true, isFinal: false, output: '0' },
          { id: 1, name: 'q1', x: 380, y: 140, isInitial: false, isFinal: false, output: '1' },
          { id: 2, name: 'q2', x: 380, y: 300, isInitial: false, isFinal: false, output: '2' }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['0'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['1'], curve: 25 },
          { id: 2, from: 1, to: 2, symbols: ['0'], curve: 25 },
          { id: 3, from: 1, to: 0, symbols: ['1'], curve: 25 },
          { id: 4, from: 2, to: 1, symbols: ['1'], curve: 25 },
          { id: 5, from: 2, to: 2, symbols: ['0'], curve: 0 }
        ]
      }
    },

    mealy_seq_101: {
      name: 'Mealy Sequence Detector (101)',
      mode: 'mealy',
      defaultInput: '110101',
      data: {
        type: 'MEALY',
        states: [
          { id: 0, name: 'q0', x: 180, y: 220, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 340, y: 220, isInitial: false, isFinal: false },
          { id: 2, name: 'q2', x: 500, y: 220, isInitial: false, isFinal: false }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['0/0'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['1/0'], curve: 0 },
          { id: 2, from: 1, to: 1, symbols: ['1/0'], curve: 0 },
          { id: 3, from: 1, to: 2, symbols: ['0/0'], curve: 0 },
          { id: 4, from: 2, to: 1, symbols: ['1/1'], curve: 40 },
          { id: 5, from: 2, to: 0, symbols: ['0/0'], curve: -50 }
        ]
      }
    }
  },

  // ===================================================================
  // PUSHDOWN AUTOMATA (PDA)
  // ===================================================================
  pda: {
    anbn: {
      name: 'PDA: aⁿ bⁿ (n ≥ 1)',
      defaultInput: 'aabb',
      acceptMode: 'final',
      data: {
        type: 'PDA',
        states: [
          { id: 0, name: 'q0', x: 160, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 340, y: 240, isInitial: false, isFinal: false },
          { id: 2, name: 'q2', x: 520, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['a, Z0 -> AZ0', 'a, A -> AA'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['b, A -> ε'], curve: 0 },
          { id: 2, from: 1, to: 1, symbols: ['b, A -> ε'], curve: 0 },
          { id: 3, from: 1, to: 2, symbols: ['ε, Z0 -> Z0'], curve: 0 }
        ]
      }
    },

    wcwr: {
      name: 'PDA: w c wᴿ (Palindromes with Marker)',
      defaultInput: '01c10',
      acceptMode: 'final',
      data: {
        type: 'PDA',
        states: [
          { id: 0, name: 'q0', x: 180, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 360, y: 240, isInitial: false, isFinal: false },
          { id: 2, name: 'q2', x: 540, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['0, Z0 -> 0Z0', '1, Z0 -> 1Z0', '0, 0 -> 00', '1, 1 -> 11', '0, 1 -> 01', '1, 0 -> 10'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['c, 0 -> 0', 'c, 1 -> 1', 'c, Z0 -> Z0'], curve: 0 },
          { id: 2, from: 1, to: 1, symbols: ['0, 0 -> ε', '1, 1 -> ε'], curve: 0 },
          { id: 3, from: 1, to: 2, symbols: ['ε, Z0 -> Z0'], curve: 0 }
        ]
      }
    },

    parens: {
      name: 'PDA: Balanced Parentheses',
      defaultInput: '(())()',
      acceptMode: 'final',
      data: {
        type: 'PDA',
        states: [
          { id: 0, name: 'q0', x: 200, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 420, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['(, Z0 -> (Z0', '(, ( -> ((', '), ( -> ε'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['ε, Z0 -> Z0'], curve: 0 }
        ]
      }
    }
  },

  // ===================================================================
  // TURING MACHINES
  // ===================================================================
  tm: {
    binary_inc: {
      name: 'TM: Binary Incrementer',
      defaultInput: '1011',
      tapeCount: 1,
      data: {
        type: 'TM',
        states: [
          { id: 0, name: 'q0', x: 160, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 360, y: 240, isInitial: false, isFinal: false },
          { id: 2, name: 'q_acc', x: 560, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 0, symbols: ['0 -> 0, R', '1 -> 1, R'], curve: 0 },
          { id: 1, from: 0, to: 1, symbols: ['_ -> _, L'], curve: 0 },
          { id: 2, from: 1, to: 1, symbols: ['1 -> 0, L'], curve: 0 },
          { id: 3, from: 1, to: 2, symbols: ['0 -> 1, R', '_ -> 1, R'], curve: 0 }
        ]
      }
    },

    palindrome: {
      name: 'TM: Palindrome Decider (w wᴿ)',
      defaultInput: '1001',
      tapeCount: 1,
      data: {
        type: 'TM',
        states: [
          { id: 0, name: 'q0', x: 140, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q_r0', x: 300, y: 150, isInitial: false, isFinal: false },
          { id: 2, name: 'q_r1', x: 300, y: 330, isInitial: false, isFinal: false },
          { id: 3, name: 'q_ret', x: 480, y: 240, isInitial: false, isFinal: false },
          { id: 4, name: 'q_acc', x: 620, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 1, symbols: ['0 -> _, R'], curve: 0 },
          { id: 1, from: 0, to: 2, symbols: ['1 -> _, R'], curve: 0 },
          { id: 2, from: 0, to: 4, symbols: ['_ -> _, S'], curve: 0 },
          { id: 3, from: 1, to: 1, symbols: ['0 -> 0, R', '1 -> 1, R'], curve: 0 },
          { id: 4, from: 1, to: 3, symbols: ['_ -> _, L'], curve: 25 },
          { id: 5, from: 2, to: 2, symbols: ['0 -> 0, R', '1 -> 1, R'], curve: 0 },
          { id: 6, from: 2, to: 3, symbols: ['_ -> _, L'], curve: 25 },
          { id: 7, from: 3, to: 0, symbols: ['_ -> _, R'], curve: 40 },
          { id: 8, from: 3, to: 3, symbols: ['0 -> 0, L', '1 -> 1, L'], curve: 0 }
        ]
      }
    },

    anbncn: {
      name: 'TM: aⁿ bⁿ cⁿ Decider',
      defaultInput: 'aabbcc',
      tapeCount: 1,
      data: {
        type: 'TM',
        states: [
          { id: 0, name: 'q0', x: 120, y: 240, isInitial: true, isFinal: false },
          { id: 1, name: 'q1', x: 260, y: 240, isInitial: false, isFinal: false },
          { id: 2, name: 'q2', x: 400, y: 240, isInitial: false, isFinal: false },
          { id: 3, name: 'q3', x: 540, y: 240, isInitial: false, isFinal: false },
          { id: 4, name: 'q_acc', x: 680, y: 240, isInitial: false, isFinal: true }
        ],
        transitions: [
          { id: 0, from: 0, to: 1, symbols: ['a -> X, R'], curve: 0 },
          { id: 1, from: 0, to: 4, symbols: ['Y -> Y, R', '_ -> _, S'], curve: 0 },
          { id: 2, from: 1, to: 1, symbols: ['a -> a, R', 'Y -> Y, R'], curve: 0 },
          { id: 3, from: 1, to: 2, symbols: ['b -> Y, R'], curve: 0 },
          { id: 4, from: 2, to: 2, symbols: ['b -> b, R', 'Z -> Z, R'], curve: 0 },
          { id: 5, from: 2, to: 3, symbols: ['c -> Z, L'], curve: 0 },
          { id: 6, from: 3, to: 3, symbols: ['a -> a, L', 'b -> b, L', 'Y -> Y, L', 'Z -> Z, L'], curve: 0 },
          { id: 7, from: 3, to: 0, symbols: ['X -> X, R'], curve: 40 }
        ]
      }
    }
  }
};
