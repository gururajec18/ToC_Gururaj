/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Master Application Controller & UI Coordinator
 */

document.addEventListener('DOMContentLoaded', () => {
  // Global Application State
  const app = {
    theme: 'dark',
    activeTab: 'tab-fa',
    
    // Finite Automata
    faAutomaton: new Automaton('FA'),
    faCanvas: null,
    faEngine: null,
    faSimTimer: null,
    faSimSpeed: 600,
    batchStrings: ['01', '101', '11001', '0', '1', '10', '00'],

    // Converted models cache
    lastComputedDfa: null,
    lastMinimizedDfa: null,

    // Transducers
    transAutomaton: new Automaton('MEALY'),
    transCanvas: null,
    transEngine: null,

    // PDA
    pdaAutomaton: new Automaton('PDA'),
    pdaCanvas: null,
    pdaEngine: null,
    pdaSimTimer: null,

    // CFG
    cfgEngine: null,

    // Turing Machine
    tmAutomaton: new Automaton('TM'),
    tmCanvas: null,
    tmEngine: null,
    tmSimTimer: null,
    tmSimSpeed: 400,

    // Pumping Lemma
    pumpingLab: new PumpingLemmaLab(),

    // L-Systems
    lsystemEngine: null
  };

  window.tocApp = app; // Accessible for debugging

  // ===================================================================
  // 1. THEME & HEADER CONTROLS
  // ===================================================================
  function initTheme() {
    const savedTheme = localStorage.getItem('toc_theme') || 'dark';
    setTheme(savedTheme);

    document.getElementById('btn-theme-toggle').addEventListener('click', () => {
      const nextTheme = app.theme === 'dark' ? 'light' : 'dark';
      setTheme(nextTheme);
    });
  }

  function setTheme(theme) {
    app.theme = theme;
    localStorage.setItem('toc_theme', theme);
    document.body.className = theme === 'dark' ? 'dark-theme' : 'light-theme';
    document.getElementById('theme-icon').textContent = theme === 'dark' ? '🌙' : '☀️';

    // Redraw canvases
    if (app.faCanvas) app.faCanvas.render();
    if (app.transCanvas) app.transCanvas.render();
    if (app.pdaCanvas) app.pdaCanvas.render();
    if (app.tmCanvas) app.tmCanvas.render();
  }

  // Presets Dropdown
  function initPresetsMenu() {
    const btnPresets = document.getElementById('btn-presets');
    const menu = document.getElementById('presets-menu');

    // Populate dropdown items
    menu.innerHTML = `
      <div style="padding:6px 14px; font-weight:700; font-size:0.75rem; color:var(--text-muted); text-transform:uppercase;">Finite Automata</div>
      <button class="dropdown-item" data-preset-cat="fa" data-preset-id="ends_with_01">DFA: Strings Ending with "01"</button>
      <button class="dropdown-item" data-preset-cat="fa" data-preset-id="even_zeros_even_ones">DFA: Even 0s & Even 1s</button>
      <button class="dropdown-item" data-preset-cat="fa" data-preset-id="divisible_by_3">DFA: Binary Divisible by 3</button>
      <button class="dropdown-item" data-preset-cat="fa" data-preset-id="nfa_abb">NFA: (a+b)*abb</button>
      <button class="dropdown-item" data-preset-cat="fa" data-preset-id="epsilon_nfa_example">ε-NFA: (01)* + (10)*</button>

      <div style="padding:6px 14px; font-weight:700; font-size:0.75rem; color:var(--text-muted); text-transform:uppercase; border-top:1px solid var(--border-color); margin-top:4px;">Transducers</div>
      <button class="dropdown-item" data-preset-cat="transducers" data-preset-id="mealy_ones_comp">Mealy: 1's Complement</button>
      <button class="dropdown-item" data-preset-cat="transducers" data-preset-id="mealy_twos_comp">Mealy: 2's Complement</button>
      <button class="dropdown-item" data-preset-cat="transducers" data-preset-id="moore_mod3">Moore: Modulo 3 Counter</button>
      <button class="dropdown-item" data-preset-cat="transducers" data-preset-id="mealy_seq_101">Mealy: Sequence 101 Detector</button>

      <div style="padding:6px 14px; font-weight:700; font-size:0.75rem; color:var(--text-muted); text-transform:uppercase; border-top:1px solid var(--border-color); margin-top:4px;">Pushdown Automata</div>
      <button class="dropdown-item" data-preset-cat="pda" data-preset-id="anbn">PDA: aⁿ bⁿ</button>
      <button class="dropdown-item" data-preset-cat="pda" data-preset-id="wcwr">PDA: w c wᴿ Palindrome</button>
      <button class="dropdown-item" data-preset-cat="pda" data-preset-id="parens">PDA: Balanced Parentheses</button>

      <div style="padding:6px 14px; font-weight:700; font-size:0.75rem; color:var(--text-muted); text-transform:uppercase; border-top:1px solid var(--border-color); margin-top:4px;">Turing Machines</div>
      <button class="dropdown-item" data-preset-cat="tm" data-preset-id="binary_inc">TM: Binary Incrementer</button>
      <button class="dropdown-item" data-preset-cat="tm" data-preset-id="palindrome">TM: Palindrome Decider</button>
      <button class="dropdown-item" data-preset-cat="tm" data-preset-id="anbncn">TM: aⁿ bⁿ cⁿ Decider</button>
    `;

    btnPresets.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('hidden');
    });

    document.addEventListener('click', () => {
      menu.classList.add('hidden');
    });

    menu.addEventListener('click', (e) => {
      const item = e.target.closest('.dropdown-item');
      if (!item) return;
      const cat = item.dataset.presetCat;
      const id = item.dataset.presetId;
      loadPreset(cat, id);
    });
  }

  function loadPreset(category, presetId) {
    const preset = TOCPresets[category]?.[presetId];
    if (!preset) return;

    if (category === 'fa') {
      switchTab('tab-fa');
      app.faAutomaton.fromJSON(preset.data);
      app.faCanvas.render();
      if (preset.defaultInput) {
        document.getElementById('fa-input-string').value = preset.defaultInput;
      }
      if (preset.batchTests) {
        app.batchStrings = [...preset.batchTests];
        renderBatchTests();
      }
      updateFAInfo();
      app.faEngine.reset();
      ExportUtils.showToast(`Loaded preset: ${preset.name}`, 'info');
    } else if (category === 'transducers') {
      switchTab('tab-transducers');
      app.transAutomaton.fromJSON(preset.data);
      const mode = preset.mode || 'mealy';
      document.querySelector(`input[name="transducer-mode"][value="${mode}"]`).checked = true;
      app.transEngine.setMode(mode);
      app.transCanvas.render();
      if (preset.defaultInput) {
        document.getElementById('transducer-input').value = preset.defaultInput;
      }
      updateTransducerUI();
      ExportUtils.showToast(`Loaded transducer: ${preset.name}`, 'info');
    } else if (category === 'pda') {
      switchTab('tab-pda');
      app.pdaAutomaton.fromJSON(preset.data);
      app.pdaCanvas.render();
      if (preset.defaultInput) {
        document.getElementById('pda-input-string').value = preset.defaultInput;
      }
      if (preset.acceptMode) {
        document.getElementById('pda-accept-mode').value = preset.acceptMode;
      }
      app.pdaEngine.setInput(document.getElementById('pda-input-string').value, document.getElementById('pda-accept-mode').value);
      renderPdaStack();
      updatePdaTransitionsTable();
      ExportUtils.showToast(`Loaded PDA: ${preset.name}`, 'info');
    } else if (category === 'tm') {
      switchTab('tab-tm');
      app.tmAutomaton.fromJSON(preset.data);
      app.tmCanvas.render();
      if (preset.defaultInput) {
        document.getElementById('tm-input-string').value = preset.defaultInput;
      }
      app.tmEngine.setInput(document.getElementById('tm-input-string').value);
      renderTmTape();
      updateTmInfo();
      ExportUtils.showToast(`Loaded TM: ${preset.name}`, 'info');
    }
  }

  // Export / Import
  function initHeaderButtons() {
    document.getElementById('btn-export-png').addEventListener('click', () => {
      let canvas = null;
      let name = 'automaton.png';

      if (app.activeTab === 'tab-fa') {
        canvas = document.getElementById('fa-canvas');
        name = 'finite_automaton.png';
      } else if (app.activeTab === 'tab-transducers') {
        canvas = document.getElementById('transducer-canvas');
        name = 'transducer_mealy_moore.png';
      } else if (app.activeTab === 'tab-pda') {
        canvas = document.getElementById('pda-canvas');
        name = 'pushdown_automaton.png';
      } else if (app.activeTab === 'tab-tm') {
        canvas = document.getElementById('tm-canvas');
        name = 'turing_machine.png';
      } else if (app.activeTab === 'tab-lsystems') {
        canvas = document.getElementById('lsystem-canvas');
        name = 'lsystem_fractal.png';
      }

      if (canvas) {
        ExportUtils.exportCanvasAsPNG(canvas, name);
      } else {
        ExportUtils.showToast('Please open an automata canvas tab to export.', 'error');
      }
    });

    document.getElementById('btn-save-json').addEventListener('click', () => {
      let aut = app.faAutomaton;
      if (app.activeTab === 'tab-transducers') aut = app.transAutomaton;
      else if (app.activeTab === 'tab-pda') aut = app.pdaAutomaton;
      else if (app.activeTab === 'tab-tm') aut = app.tmAutomaton;

      ExportUtils.saveToJSON(aut, `${aut.type.toLowerCase()}_model.json`);
    });

    const fileInput = document.getElementById('file-input-json');
    document.getElementById('btn-load-json').addEventListener('click', () => {
      fileInput.click();
    });

    fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        ExportUtils.loadFromJSON(e.target.files[0], (data) => {
          let target = app.faAutomaton;
          let canvas = app.faCanvas;

          if (data.type === 'MEALY' || data.type === 'MOORE') {
            switchTab('tab-transducers');
            target = app.transAutomaton;
            canvas = app.transCanvas;
          } else if (data.type === 'PDA') {
            switchTab('tab-pda');
            target = app.pdaAutomaton;
            canvas = app.pdaCanvas;
          } else if (data.type === 'TM') {
            switchTab('tab-tm');
            target = app.tmAutomaton;
            canvas = app.tmCanvas;
          } else {
            switchTab('tab-fa');
          }

          target.fromJSON(data);
          canvas.render();
          updateFAInfo();
        });
        fileInput.value = '';
      }
    });

    // Help Modal
    const helpModal = document.getElementById('help-modal');
    document.getElementById('btn-help').addEventListener('click', () => {
      helpModal.classList.remove('hidden');
    });
    document.getElementById('help-modal-close').addEventListener('click', () => {
      helpModal.classList.add('hidden');
    });
    document.getElementById('help-modal-ok').addEventListener('click', () => {
      helpModal.classList.add('hidden');
    });
  }

  // ===================================================================
  // 2. TAB ROUTING
  // ===================================================================
  function initTabs() {
    document.querySelectorAll('.main-tabs .tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tabId = btn.dataset.tab;
        switchTab(tabId);
      });
    });

    // Subtabs in Conversions
    document.querySelectorAll('#tab-conversions .subtab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#tab-conversions .subtab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('#tab-conversions .subtab-pane').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.subtab).classList.add('active');
      });
    });

    // Subtabs in CFG
    document.querySelectorAll('#tab-cfg .subtab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#tab-cfg .subtab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('#tab-cfg .subtab-pane').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.subtab).classList.add('active');
      });
    });
  }

  function switchTab(tabId) {
    app.activeTab = tabId;
    document.querySelectorAll('.main-tabs .tab-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === tabId);
    });
    document.querySelectorAll('.app-workspace .tab-panel').forEach(p => {
      p.classList.toggle('active', p.id === tabId);
    });

    // Trigger canvas resizing
    setTimeout(() => {
      if (tabId === 'tab-fa' && app.faCanvas) app.faCanvas.resize();
      if (tabId === 'tab-transducers' && app.transCanvas) app.transCanvas.resize();
      if (tabId === 'tab-pda' && app.pdaCanvas) app.pdaCanvas.resize();
      if (tabId === 'tab-tm' && app.tmCanvas) app.tmCanvas.resize();
      if (tabId === 'tab-lsystems' && app.lsystemEngine) {
        document.getElementById('btn-render-lsystem').click();
      }
    }, 50);
  }

  // ===================================================================
  // 3. FINITE AUTOMATA (TAB 1) SETUP & SIMULATION
  // ===================================================================
  function initFA() {
    const canvasEl = document.getElementById('fa-canvas');
    app.faCanvas = new AutomataCanvas(canvasEl, app.faAutomaton, {
      onModelChange: () => {
        updateFAInfo();
        app.faEngine.reset();
      },
      onAddTransitionPrompt: (from, to) => {
        openEditTransitionModal(from, to);
      },
      onStateDoubleClick: (state) => {
        openEditStateModal(state);
      },
      onTransitionDoubleClick: (trans) => {
        const from = app.faAutomaton.getState(trans.from);
        const to = app.faAutomaton.getState(trans.to);
        openEditTransitionModal(from, to, trans);
      }
    });

    app.faEngine = new FAEngine(app.faAutomaton);

    // Toolbar tools
    document.querySelectorAll('#tab-fa .tool-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tool = btn.dataset.tool;
        if (!tool) return;
        document.querySelectorAll('#tab-fa .tool-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        app.faCanvas.setTool(tool);
      });
    });

    // Canvas actions
    document.getElementById('btn-auto-layout').addEventListener('click', () => app.faCanvas.autoLayout());
    document.getElementById('btn-fit-zoom').addEventListener('click', () => app.faCanvas.resetView());
    document.getElementById('btn-clear-canvas').addEventListener('click', () => {
      if (confirm('Clear all states and transitions from canvas?')) {
        app.faAutomaton.clear();
        app.faCanvas.render();
        updateFAInfo();
        app.faEngine.reset();
      }
    });

    // Simulation bar
    const inputField = document.getElementById('fa-input-string');
    const stepBtn = document.getElementById('btn-step-sim');
    const playBtn = document.getElementById('btn-play-sim');
    const pauseBtn = document.getElementById('btn-pause-sim');
    const resetBtn = document.getElementById('btn-reset-sim');
    const speedSlider = document.getElementById('sim-speed');
    const speedLabel = document.getElementById('speed-label');

    speedSlider.addEventListener('input', () => {
      app.faSimSpeed = parseInt(speedSlider.value, 10);
      speedLabel.textContent = `${app.faSimSpeed}ms`;
      if (app.faSimTimer) {
        clearInterval(app.faSimTimer);
        app.faSimTimer = setInterval(stepFASim, app.faSimSpeed);
      }
    });

    stepBtn.addEventListener('click', () => {
      pauseFASim();
      stepFASim();
    });

    playBtn.addEventListener('click', () => {
      if (app.faEngine.isFinished) {
        resetFASim();
      }
      playFASim();
    });

    pauseBtn.addEventListener('click', () => pauseFASim());
    resetBtn.addEventListener('click', () => resetFASim());

    inputField.addEventListener('input', () => {
      resetFASim();
    });

    // Multi-Run Batch Tester
    document.getElementById('btn-add-batch-string').addEventListener('click', () => {
      const val = document.getElementById('batch-new-string').value.trim();
      if (val !== '' && !app.batchStrings.includes(val)) {
        app.batchStrings.push(val);
        document.getElementById('batch-new-string').value = '';
        renderBatchTests();
      }
    });

    document.getElementById('btn-run-all-tests').addEventListener('click', () => {
      runAllBatchTests();
    });

    document.getElementById('btn-refresh-table').addEventListener('click', () => {
      updateTransitionTable();
    });

    document.getElementById('btn-clear-log').addEventListener('click', () => {
      document.getElementById('fa-execution-trace').innerHTML = '<div class="trace-entry info">Trace cleared.</div>';
    });

    // Initial load with Ends with 01
    loadPreset('fa', 'ends_with_01');
  }

  function playFASim() {
    document.getElementById('btn-play-sim').classList.add('hidden');
    document.getElementById('btn-pause-sim').classList.remove('hidden');

    const statusBadge = document.getElementById('sim-status-badge');
    statusBadge.className = 'sim-status running';
    statusBadge.querySelector('.status-text').textContent = 'Running...';

    if (app.faSimTimer) clearInterval(app.faSimTimer);
    app.faSimTimer = setInterval(() => {
      const res = stepFASim();
      if (!res || res.finished) {
        pauseFASim();
      }
    }, app.faSimSpeed);
  }

  function pauseFASim() {
    if (app.faSimTimer) {
      clearInterval(app.faSimTimer);
      app.faSimTimer = null;
    }
    document.getElementById('btn-pause-sim').classList.add('hidden');
    document.getElementById('btn-play-sim').classList.remove('hidden');
  }

  function resetFASim() {
    pauseFASim();
    const str = document.getElementById('fa-input-string').value;
    app.faEngine.setInput(str);
    app.faCanvas.setActiveStates(Array.from(app.faEngine.activeStates));
    app.faCanvas.setActiveTransitions([]);

    const statusBadge = document.getElementById('sim-status-badge');
    statusBadge.className = 'sim-status idle';
    statusBadge.querySelector('.status-text').textContent = 'Ready';

    updateActiveStatesDisplay();
    document.getElementById('fa-execution-trace').innerHTML = '<div class="trace-entry info">Simulation reset. Ready for step/run.</div>';
  }

  function stepFASim() {
    const inputStr = document.getElementById('fa-input-string').value;
    if (app.faEngine.history.length === 0) {
      app.faEngine.setInput(inputStr);
    }

    const stepResult = app.faEngine.step();
    if (!stepResult) return null;

    app.faCanvas.setActiveStates(stepResult.activeStates || []);
    app.faCanvas.setActiveTransitions(stepResult.traversedTransitions || []);

    updateActiveStatesDisplay();

    // Log trace
    const logBox = document.getElementById('fa-execution-trace');
    const entry = document.createElement('div');

    if (stepResult.finished) {
      const statusBadge = document.getElementById('sim-status-badge');
      if (stepResult.accepted) {
        statusBadge.className = 'sim-status accepted';
        statusBadge.querySelector('.status-text').textContent = 'ACCEPTED ✓';
        entry.className = 'trace-entry accept';
        entry.innerHTML = `✓ ACCEPTED: Finished in accepting state set.`;
      } else {
        statusBadge.className = 'sim-status rejected';
        statusBadge.querySelector('.status-text').textContent = 'REJECTED ✗';
        entry.className = 'trace-entry reject';
        entry.innerHTML = `✗ REJECTED: Final configuration not accepting.`;
      }
    } else {
      entry.className = 'trace-entry step';
      entry.innerHTML = `Read '<strong>${stepResult.charRead}</strong>' &rarr; Active: { ${stepResult.activeStates.map(id => app.faAutomaton.getState(id)?.name || id).join(', ')} }`;
    }

    logBox.appendChild(entry);
    logBox.scrollTop = logBox.scrollHeight;

    return stepResult;
  }

  function updateFAInfo() {
    const statesCount = app.faAutomaton.states.size;
    const transCount = app.faAutomaton.transitions.length;
    const alphabet = app.faAutomaton.getAlphabet();
    const finals = app.faAutomaton.getFinalStates().length;
    const isDfa = app.faAutomaton.isDFA();

    document.getElementById('stat-states').textContent = statesCount;
    document.getElementById('stat-trans').textContent = transCount;
    document.getElementById('stat-alphabet').textContent = alphabet.length > 0 ? `{ ${alphabet.join(', ')} }` : '∅';
    document.getElementById('stat-finals').textContent = finals;

    const badge = document.getElementById('fa-type-badge');
    badge.textContent = isDfa ? 'DFA' : 'NFA / ε-NFA';
    badge.className = `type-badge ${isDfa ? 'badge-dfa' : 'badge-nfa'}`;

    updateTransitionTable();
    updateActiveStatesDisplay();
  }

  function updateActiveStatesDisplay() {
    const display = document.getElementById('active-states-display');
    const names = Array.from(app.faEngine.activeStates)
      .map(id => app.faAutomaton.getState(id)?.name || `q${id}`);
    display.textContent = names.length > 0 ? `{ ${names.join(', ')} }` : '∅';
  }

  function updateTransitionTable() {
    const container = document.getElementById('transition-table-container');
    container.innerHTML = app.faEngine.generateTransitionTable();
  }

  function renderBatchTests() {
    const list = document.getElementById('batch-tests-list');
    list.innerHTML = '';

    app.batchStrings.forEach((str, idx) => {
      const item = document.createElement('div');
      item.className = 'batch-test-item';
      item.innerHTML = `
        <span>"${str}"</span>
        <div style="display:flex; align-items:center; gap:6px;">
          <span class="batch-test-status pending" id="batch-status-${idx}">Pending</span>
          <button class="btn-del-batch" data-idx="${idx}" title="Remove">&times;</button>
        </div>
      `;
      list.appendChild(item);
    });

    list.querySelectorAll('.btn-del-batch').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.idx, 10);
        app.batchStrings.splice(idx, 1);
        renderBatchTests();
      });
    });
  }

  function runAllBatchTests() {
    const results = app.faEngine.runBatchTests(app.batchStrings);
    results.forEach((res, idx) => {
      const badge = document.getElementById(`batch-status-${idx}`);
      if (badge) {
        badge.className = `batch-test-status ${res.accepted ? 'pass' : 'fail'}`;
        badge.textContent = res.accepted ? 'ACCEPT ✓' : 'REJECT ✗';
      }
    });
    ExportUtils.showToast('Batch string test complete.', 'info');
  }

  // ===================================================================
  // 4. CONVERSIONS (TAB 2)
  // ===================================================================
  function initConversions() {
    // 4.1 NFA -> DFA
    const btnNfaDfa = document.getElementById('btn-compute-nfa-dfa');
    const btnLoadDfa = document.getElementById('btn-load-dfa-to-canvas');
    const nfaSummary = document.getElementById('nfa-dfa-summary');
    const nfaTableContainer = document.getElementById('nfa-dfa-table-container');

    btnNfaDfa.addEventListener('click', () => {
      try {
        const result = AutomataConversions.nfaToDfa(app.faAutomaton);
        app.lastComputedDfa = result.dfa;

        nfaSummary.innerHTML = `
          <div class="status-callout success">
            Subset construction completed! Generated <strong>${result.subsetsMap.size}</strong> DFA states from <strong>${app.faAutomaton.states.size}</strong> NFA states.
          </div>
        `;

        // Render subset table
        let tblHtml = '<table class="clean-table"><thead><tr><th>DFA State Subset</th>';
        for (const a of result.alphabet) tblHtml += `<th>Input '${a}'</th>`;
        tblHtml += '</tr></thead><tbody>';

        for (const row of result.transitionsTable) {
          const initMark = row.isInitial ? '&rarr; ' : '';
          const finalMark = row.isFinal ? '* ' : '';
          tblHtml += `<tr><td class="state-name">${initMark}${finalMark}${row.state}</td>`;
          for (const a of result.alphabet) {
            tblHtml += `<td>${row.moves[a]}</td>`;
          }
          tblHtml += '</tr>';
        }
        tblHtml += '</tbody></table>';

        nfaTableContainer.innerHTML = tblHtml;
        btnLoadDfa.disabled = false;
        ExportUtils.showToast('NFA to DFA conversion computed!', 'success');
      } catch (err) {
        nfaSummary.innerHTML = `<div class="status-callout warning">Error: ${err.message}</div>`;
        ExportUtils.showToast(err.message, 'error');
      }
    });

    btnLoadDfa.addEventListener('click', () => {
      if (app.lastComputedDfa) {
        app.faAutomaton = app.lastComputedDfa;
        app.faCanvas.automaton = app.faAutomaton;
        app.faEngine.automaton = app.faAutomaton;
        app.faCanvas.render();
        updateFAInfo();
        switchTab('tab-fa');
        ExportUtils.showToast('DFA loaded onto main canvas!', 'success');
      }
    });

    // 4.2 DFA Minimization
    const btnDfaMin = document.getElementById('btn-run-dfa-min');
    const btnLoadMin = document.getElementById('btn-load-min-dfa');
    const minStepsBox = document.getElementById('dfa-min-steps-box');
    const minTableContainer = document.getElementById('dfa-min-table-container');

    btnDfaMin.addEventListener('click', () => {
      try {
        const result = AutomataConversions.minimizeDfa(app.faAutomaton);
        app.lastMinimizedDfa = result.minDfa;

        minStepsBox.innerHTML = result.steps.map(s => `<div>&bull; ${s}</div>`).join('');

        // Render staircase table
        const n = result.stateList.length;
        let sHtml = '<table class="staircase-table"><tbody>';

        for (let i = 1; i < n; i++) {
          sHtml += `<tr><th>${result.stateList[i].name}</th>`;
          for (let j = 0; j < i; j++) {
            const isDist = result.table[j][i];
            sHtml += `<td class="${isDist ? 'distinguishable' : 'equivalent'}">${isDist ? 'X' : '≡'}</td>`;
          }
          sHtml += '</tr>';
        }

        sHtml += '<tr><td></td>';
        for (let j = 0; j < n - 1; j++) {
          sHtml += `<th>${result.stateList[j].name}</th>`;
        }
        sHtml += '</tr></tbody></table>';

        minTableContainer.innerHTML = sHtml;
        btnLoadMin.disabled = false;
        ExportUtils.showToast('DFA minimization complete!', 'success');
      } catch (err) {
        minStepsBox.innerHTML = `<div class="status-callout warning">Error: ${err.message}</div>`;
        ExportUtils.showToast(err.message, 'error');
      }
    });

    btnLoadMin.addEventListener('click', () => {
      if (app.lastMinimizedDfa) {
        app.faAutomaton = app.lastMinimizedDfa;
        app.faCanvas.automaton = app.faAutomaton;
        app.faEngine.automaton = app.faAutomaton;
        app.faCanvas.render();
        updateFAInfo();
        switchTab('tab-fa');
        ExportUtils.showToast('Minimized DFA loaded onto main canvas!', 'success');
      }
    });

    // 4.3 FA to Regex
    document.getElementById('btn-run-fa-regex').addEventListener('click', () => {
      try {
        const result = AutomataConversions.faToRegex(app.faAutomaton);
        document.getElementById('fa-regex-output').innerHTML = `<code>${result.regex}</code>`;
        document.getElementById('fa-regex-steps-log').innerHTML = result.steps.map(s => `<div>&bull; ${s}</div>`).join('');
        ExportUtils.showToast('Regular expression extracted!', 'success');
      } catch (err) {
        document.getElementById('fa-regex-output').textContent = `Error: ${err.message}`;
      }
    });

    // 4.4 Regex to NFA (Thompson's)
    document.querySelectorAll('.chip-btn[data-regex]').forEach(chip => {
      chip.addEventListener('click', () => {
        document.getElementById('regex-input-string').value = chip.dataset.regex;
      });
    });

    let currentRegexNfa = null;

    document.getElementById('btn-build-regex-nfa').addEventListener('click', () => {
      try {
        const regexStr = document.getElementById('regex-input-string').value.trim();
        currentRegexNfa = AutomataConversions.regexToNfa(regexStr);

        const preview = document.getElementById('regex-nfa-preview');
        preview.innerHTML = `
          <div class="status-callout success">
            Successfully constructed &epsilon;-NFA for <code>${regexStr}</code>!
            <br>&bull; States: ${currentRegexNfa.states.size}
            <br>&bull; Transitions: ${currentRegexNfa.transitions.length}
            <br>&bull; Initial State: ${currentRegexNfa.getInitialState()?.name}
            <br>&bull; Accepting State: ${currentRegexNfa.getFinalStates().map(s => s.name).join(', ')}
          </div>
        `;
        ExportUtils.showToast("Thompson's NFA generated!", 'success');
      } catch (err) {
        document.getElementById('regex-nfa-preview').innerHTML = `<div class="status-callout warning">Error: ${err.message}</div>`;
      }
    });

    document.getElementById('btn-load-regex-to-canvas').addEventListener('click', () => {
      if (!currentRegexNfa) {
        document.getElementById('btn-build-regex-nfa').click();
      }
      if (currentRegexNfa) {
        app.faAutomaton = currentRegexNfa;
        app.faCanvas.automaton = app.faAutomaton;
        app.faEngine.automaton = app.faAutomaton;
        app.faCanvas.render();
        updateFAInfo();
        switchTab('tab-fa');
        ExportUtils.showToast('ε-NFA loaded onto canvas!', 'success');
      }
    });

    // 4.5 Grammar <-> FA
    document.getElementById('btn-grammar-to-fa').addEventListener('click', () => {
      const text = document.getElementById('reg-grammar-input').value;
      const nfa = AutomataConversions.grammarToFa(text);
      app.faAutomaton = nfa;
      app.faCanvas.automaton = app.faAutomaton;
      app.faEngine.automaton = app.faAutomaton;
      app.faCanvas.render();
      updateFAInfo();

      document.getElementById('grammar-fa-result').innerHTML = `
        <div class="status-callout success">
          Converted grammar to NFA with ${nfa.states.size} states! Loaded onto main canvas.
        </div>
      `;
      switchTab('tab-fa');
      ExportUtils.showToast('Grammar converted to FA!', 'success');
    });

    document.getElementById('btn-fa-to-grammar').addEventListener('click', () => {
      const grammar = AutomataConversions.faToGrammar(app.faAutomaton);
      document.getElementById('grammar-fa-result').innerHTML = `
        <div class="status-callout info">Extracted Right-Linear Grammar:</div>
        <pre class="formula-code" style="font-size:0.85rem;">${grammar}</pre>
      `;
    });
  }

  // ===================================================================
  // 5. TRANSDUCERS (MEALY & MOORE)
  // ===================================================================
  function initTransducers() {
    const canvasEl = document.getElementById('transducer-canvas');
    app.transCanvas = new AutomataCanvas(canvasEl, app.transAutomaton, {
      onModelChange: () => updateTransducerUI(),
      onAddTransitionPrompt: (from, to) => openEditTransitionModal(from, to, null, true),
      onStateDoubleClick: (state) => openEditStateModal(state, true),
      onTransitionDoubleClick: (trans) => {
        const from = app.transAutomaton.getState(trans.from);
        const to = app.transAutomaton.getState(trans.to);
        openEditTransitionModal(from, to, trans, true);
      }
    });

    app.transEngine = new MealyMooreEngine(app.transAutomaton, 'mealy');

    // Mode Toggle
    document.querySelectorAll('input[name="transducer-mode"]').forEach(radio => {
      radio.addEventListener('change', () => {
        const mode = radio.value;
        app.transEngine.setMode(mode);
        app.transCanvas.render();
        updateTransducerUI();
      });
    });

    // Step / Run / Reset
    document.getElementById('btn-transducer-step').addEventListener('click', () => {
      stepTransducer();
    });

    document.getElementById('btn-transducer-run').addEventListener('click', () => {
      runTransducer();
    });

    document.getElementById('btn-transducer-reset').addEventListener('click', () => {
      resetTransducer();
    });

    // Converter Mealy <-> Moore
    document.getElementById('btn-convert-transducer').addEventListener('click', () => {
      try {
        if (app.transEngine.mode === 'mealy') {
          const moore = MealyMooreEngine.convertMealyToMoore(app.transAutomaton);
          app.transAutomaton = moore;
          app.transCanvas.automaton = moore;
          app.transEngine.automaton = moore;
          app.transEngine.setMode('moore');
          document.querySelector('input[name="transducer-mode"][value="moore"]').checked = true;
          ExportUtils.showToast('Converted Mealy to Moore Machine!', 'success');
        } else {
          const mealy = MealyMooreEngine.convertMooreToMealy(app.transAutomaton);
          app.transAutomaton = mealy;
          app.transCanvas.automaton = mealy;
          app.transEngine.automaton = mealy;
          app.transEngine.setMode('mealy');
          document.querySelector('input[name="transducer-mode"][value="mealy"]').checked = true;
          ExportUtils.showToast('Converted Moore to Mealy Machine!', 'success');
        }
        app.transCanvas.render();
        updateTransducerUI();
      } catch (err) {
        ExportUtils.showToast(err.message, 'error');
      }
    });

    // Presets
    document.getElementById('btn-preset-mealy-1s-comp').addEventListener('click', () => loadPreset('transducers', 'mealy_ones_comp'));
    document.getElementById('btn-preset-mealy-2s-comp').addEventListener('click', () => loadPreset('transducers', 'mealy_twos_comp'));
    document.getElementById('btn-preset-moore-mod3').addEventListener('click', () => loadPreset('transducers', 'moore_mod3'));
    document.getElementById('btn-preset-mealy-seq').addEventListener('click', () => loadPreset('transducers', 'mealy_seq_101'));

    loadPreset('transducers', 'mealy_ones_comp');
  }

  function resetTransducer() {
    const input = document.getElementById('transducer-input').value;
    app.transEngine.setInput(input);
    app.transCanvas.setActiveStates(app.transEngine.currentState ? [app.transEngine.currentState.id] : []);
    app.transCanvas.setActiveTransitions([]);
    renderTransducerStreams();
  }

  function stepTransducer() {
    if (app.transEngine.inputString === '') {
      resetTransducer();
    }
    const res = app.transEngine.step();
    if (!res) return;

    if (res.currentState) {
      app.transCanvas.setActiveStates([res.currentState.id]);
    }
    if (res.traversedTransitionId !== undefined) {
      app.transCanvas.setActiveTransitions([res.traversedTransitionId]);
    }

    renderTransducerStreams();
  }

  function runTransducer() {
    resetTransducer();
    while (!app.transEngine.isFinished) {
      app.transEngine.step();
    }
    if (app.transEngine.currentState) {
      app.transCanvas.setActiveStates([app.transEngine.currentState.id]);
    }
    renderTransducerStreams();
    ExportUtils.showToast('Transducer execution completed.', 'info');
  }

  function renderTransducerStreams() {
    const inBox = document.getElementById('transducer-input-stream');
    const stateBox = document.getElementById('transducer-state-stream');
    const outBox = document.getElementById('transducer-output-stream');

    const inputChars = app.transEngine.inputString.split('');
    const activeIdx = app.transEngine.charIndex;

    inBox.innerHTML = inputChars.map((ch, idx) => `
      <span class="stream-char ${idx === activeIdx ? 'active' : ''}">${ch}</span>
    `).join('') || '<span style="color:var(--text-muted); font-size:0.75rem;">(empty)</span>';

    stateBox.innerHTML = app.transEngine.stateStream.map(s => `
      <span class="stream-char">${s}</span>
    `).join('') || '<span style="color:var(--text-muted); font-size:0.75rem;">-</span>';

    outBox.innerHTML = app.transEngine.outputStream.map(o => `
      <span class="stream-char">${o}</span>
    `).join('') || '<span style="color:var(--text-muted); font-size:0.75rem;">-</span>';
  }

  function updateTransducerUI() {
    document.getElementById('transducer-table-container').innerHTML = app.transEngine.generateTable();
    resetTransducer();
  }

  // ===================================================================
  // 6. PUSHDOWN AUTOMATA (PDA - TAB 4)
  // ===================================================================
  function initPDA() {
    const canvasEl = document.getElementById('pda-canvas');
    app.pdaCanvas = new AutomataCanvas(canvasEl, app.pdaAutomaton, {
      onModelChange: () => {
        updatePdaTransitionsTable();
        app.pdaEngine.reset();
      },
      onAddTransitionPrompt: (from, to) => openEditTransitionModal(from, to, null, false, 'PDA'),
      onStateDoubleClick: (state) => openEditStateModal(state),
      onTransitionDoubleClick: (trans) => {
        const from = app.pdaAutomaton.getState(trans.from);
        const to = app.pdaAutomaton.getState(trans.to);
        openEditTransitionModal(from, to, trans, false, 'PDA');
      }
    });

    app.pdaEngine = new PDAEngine(app.pdaAutomaton);

    // Tools
    document.querySelectorAll('#tab-pda .tool-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tool = btn.dataset.pdaTool;
        if (!tool) return;
        document.querySelectorAll('#tab-pda .tool-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        app.pdaCanvas.setTool(tool);
      });
    });

    // Sim Controls
    document.getElementById('btn-pda-step').addEventListener('click', () => stepPDA());
    document.getElementById('btn-pda-run').addEventListener('click', () => runPDA());
    document.getElementById('btn-pda-reset').addEventListener('click', () => resetPDA());

    // Presets
    document.getElementById('btn-pda-preset-anbn').addEventListener('click', () => loadPreset('pda', 'anbn'));
    document.getElementById('btn-pda-preset-wwr').addEventListener('click', () => loadPreset('pda', 'wcwr'));
    document.getElementById('btn-pda-preset-parens').addEventListener('click', () => loadPreset('pda', 'parens'));

    loadPreset('pda', 'anbn');
  }

  function resetPDA() {
    const input = document.getElementById('pda-input-string').value;
    const mode = document.getElementById('pda-accept-mode').value;
    app.pdaEngine.setInput(input, mode);
    app.pdaCanvas.setActiveStates(app.pdaEngine.currentState ? [app.pdaEngine.currentState.id] : []);
    app.pdaCanvas.setActiveTransitions([]);

    renderPdaStack();
    document.getElementById('pda-trace-log').innerHTML = '<div class="trace-entry info">PDA initialized with Z0 on stack.</div>';

    const statusBadge = document.getElementById('pda-status-badge');
    statusBadge.className = 'sim-status idle';
    statusBadge.querySelector('.status-text').textContent = 'Ready';
  }

  function stepPDA() {
    const res = app.pdaEngine.step();
    if (!res) return;

    if (res.currentState) {
      app.pdaCanvas.setActiveStates([res.currentState.id]);
    }
    if (res.traversedTransitionId !== undefined) {
      app.pdaCanvas.setActiveTransitions([res.traversedTransitionId]);
    }

    renderPdaStack();

    const traceLog = document.getElementById('pda-trace-log');
    const lastHistory = app.pdaEngine.history[app.pdaEngine.history.length - 1];
    if (lastHistory) {
      const entry = document.createElement('div');
      entry.className = `trace-entry ${res.finished ? (res.accepted ? 'accept' : 'reject') : 'step'}`;
      entry.innerHTML = `<code>${lastHistory.id}</code> &bull; ${lastHistory.desc}`;
      traceLog.appendChild(entry);
      traceLog.scrollTop = traceLog.scrollHeight;
    }

    if (res.finished) {
      const statusBadge = document.getElementById('pda-status-badge');
      if (res.accepted) {
        statusBadge.className = 'sim-status accepted';
        statusBadge.querySelector('.status-text').textContent = 'ACCEPTED ✓';
      } else {
        statusBadge.className = 'sim-status rejected';
        statusBadge.querySelector('.status-text').textContent = 'REJECTED ✗';
      }
    }
  }

  function runPDA() {
    resetPDA();
    let maxSteps = 500;
    while (!app.pdaEngine.isFinished && maxSteps-- > 0) {
      stepPDA();
    }
  }

  function renderPdaStack() {
    const container = document.getElementById('pda-stack-container');
    const heightLabel = document.getElementById('pda-stack-height');
    container.innerHTML = '';

    const stackItems = app.pdaEngine.stack;
    heightLabel.textContent = `${stackItems.length} items`;

    if (stackItems.length === 0) {
      container.innerHTML = '<div class="stack-cell stack-bottom" style="opacity:0.5;">(Empty Stack)</div>';
      return;
    }

    stackItems.forEach((sym, idx) => {
      const cell = document.createElement('div');
      cell.className = `stack-cell ${idx === 0 ? 'stack-bottom' : ''}`;
      cell.textContent = sym;
      container.appendChild(cell);
    });
  }

  function updatePdaTransitionsTable() {
    const container = document.getElementById('pda-transitions-table');
    let html = '<table class="clean-table"><thead><tr><th>From</th><th>Transition (a, X &rarr; α)</th><th>To</th></tr></thead><tbody>';

    for (const t of app.pdaAutomaton.transitions) {
      const from = app.pdaAutomaton.getState(t.from);
      const to = app.pdaAutomaton.getState(t.to);
      if (!from || !to) continue;

      for (const s of t.symbols) {
        html += `<tr><td class="state-name">${from.name}</td><td><code>${s}</code></td><td class="state-name">${to.name}</td></tr>`;
      }
    }

    html += '</tbody></table>';
    container.innerHTML = html;
  }

  // ===================================================================
  // 7. CFG & PARSING (TAB 5)
  // ===================================================================
  function initCFG() {
    const inputArea = document.getElementById('cfg-grammar-input');
    const btnAnalyze = document.getElementById('btn-compute-cfg');

    btnAnalyze.addEventListener('click', () => {
      analyzeCFG();
    });

    // Presets
    document.getElementById('btn-cfg-preset-arith').addEventListener('click', () => {
      inputArea.value = `E -> T E'
E' -> + T E' | ε
T -> F T'
T' -> * F T' | ε
F -> ( E ) | id`;
      analyzeCFG();
    });

    document.getElementById('btn-cfg-preset-parens').addEventListener('click', () => {
      inputArea.value = `S -> ( S ) S | ε`;
      analyzeCFG();
    });

    document.getElementById('btn-cfg-preset-anbn').addEventListener('click', () => {
      inputArea.value = `S -> a S b | ε`;
      analyzeCFG();
    });

    document.getElementById('btn-cfg-preset-ll1-ok').addEventListener('click', () => {
      inputArea.value = `S -> A B
A -> a A | ε
B -> b B | c`;
      analyzeCFG();
    });

    // LL(1) string parse
    document.getElementById('btn-ll1-parse').addEventListener('click', () => {
      if (!app.cfgEngine) analyzeCFG();
      const str = document.getElementById('ll1-input-string').value;
      const res = app.cfgEngine.simulateLL1Parse(str);
      const traceContainer = document.getElementById('ll1-parse-trace-container');

      if (!res.trace) {
        traceContainer.innerHTML = `<div class="status-callout warning">${res.error}</div>`;
        return;
      }

      let tbl = '<table class="clean-table"><thead><tr><th>Step</th><th>Stack</th><th>Input</th><th>Action</th></tr></thead><tbody>';
      res.trace.forEach((row, idx) => {
        tbl += `<tr>
          <td>${idx + 1}</td>
          <td><code>${row.stack}</code></td>
          <td><code>${row.input}</code></td>
          <td><strong>${row.action}</strong></td>
        </tr>`;
      });
      tbl += '</tbody></table>';
      traceContainer.innerHTML = tbl;
    });

    // CNF Pipeline
    document.getElementById('btn-run-cnf-convert').addEventListener('click', () => {
      const text = inputArea.value;
      const res = CFGEngine.convertToCNF(text);
      const container = document.getElementById('cnf-pipeline-steps');

      container.innerHTML = res.steps.map(st => `
        <div class="cnf-step-card">
          <div class="cnf-step-title">${st.title}</div>
          ${st.desc ? `<div style="font-size:0.78rem; color:var(--text-secondary); margin-bottom:4px;">${st.desc}</div>` : ''}
          <pre class="formula-code" style="font-size:0.8rem; margin:0;">${st.content}</pre>
        </div>
      `).join('');

      ExportUtils.showToast('Converted to Chomsky Normal Form (CNF)!', 'success');
    });

    // CFG to PDA
    let lastCfgPda = null;
    document.getElementById('btn-cfg-to-pda').addEventListener('click', () => {
      const text = inputArea.value;
      lastCfgPda = PDAEngine.cfgToPda(text);

      const rulesBox = document.getElementById('cfg-pda-rules-container');
      rulesBox.innerHTML = `
        <div class="status-callout success">
          Generated 3-State Top-Down PDA for CFG!
          <br>&bull; Terminals: { ${lastCfgPda.terminals.join(', ')} }
          <br>&bull; Non-Terminals: { ${lastCfgPda.nonTerminals.join(', ')} }
          <br>&bull; Productions expanded on loop state q1: ${lastCfgPda.rules.length}
        </div>
      `;
      ExportUtils.showToast('Constructed PDA from CFG!', 'success');
    });

    document.getElementById('btn-load-cfg-pda-canvas').addEventListener('click', () => {
      if (!lastCfgPda) document.getElementById('btn-cfg-to-pda').click();
      if (lastCfgPda) {
        app.pdaAutomaton = lastCfgPda.pda;
        app.pdaCanvas.automaton = app.pdaAutomaton;
        app.pdaEngine.automaton = app.pdaAutomaton;
        app.pdaCanvas.render();
        updatePdaTransitionsTable();
        switchTab('tab-pda');
        ExportUtils.showToast('PDA loaded onto PDA Canvas!', 'success');
      }
    });

    analyzeCFG();
  }

  function analyzeCFG() {
    const text = document.getElementById('cfg-grammar-input').value;
    app.cfgEngine = new CFGEngine(text);

    // 1. FIRST & FOLLOW Sets
    const first = app.cfgEngine.computeFirstSets();
    const follow = app.cfgEngine.computeFollowSets();

    let ffHtml = '<table class="clean-table"><thead><tr><th>Non-Terminal</th><th>FIRST</th><th>FOLLOW</th></tr></thead><tbody>';
    for (const nt of app.cfgEngine.nonTerminals) {
      const firstSet = Array.from(first.get(nt) || []).sort();
      const followSet = Array.from(follow.get(nt) || []).sort();

      ffHtml += `<tr>
        <td class="state-name"><strong>${nt}</strong></td>
        <td>{ ${firstSet.join(', ')} }</td>
        <td>{ ${followSet.join(', ')} }</td>
      </tr>`;
    }
    ffHtml += '</tbody></table>';
    document.getElementById('cfg-ff-container').innerHTML = ffHtml;

    // 2. LL(1) Table
    const ll1 = app.cfgEngine.buildLL1Table();
    const ll1Banner = document.getElementById('ll1-status-banner');
    if (ll1.isLL1) {
      ll1Banner.className = 'status-callout success';
      ll1Banner.textContent = '✓ Grammar is LL(1)! Can be parsed deterministically.';
    } else {
      ll1Banner.className = 'status-callout warning';
      ll1Banner.textContent = `✗ Not LL(1) due to conflicts: ${ll1.conflicts.join('; ')}`;
    }

    const terminalsWithEnd = [...Array.from(app.cfgEngine.terminals).sort(), '$'];
    let ll1Html = '<table class="clean-table"><thead><tr><th>Non-Terminal</th>';
    for (const t of terminalsWithEnd) ll1Html += `<th>${t}</th>`;
    ll1Html += '</tr></thead><tbody>';

    for (const nt of app.cfgEngine.nonTerminals) {
      ll1Html += `<tr><td class="state-name"><strong>${nt}</strong></td>`;
      for (const t of terminalsWithEnd) {
        const cell = ll1.table.get(nt)?.get(t) || [];
        const cellStr = cell.map(p => `${p.lhs} &rarr; ${p.rawRhs}`).join('<br>');
        const isConflict = cell.length > 1;
        ll1Html += `<td style="${isConflict ? 'background:rgba(244,63,94,0.2); font-weight:700;' : ''}">${cellStr || '-'}</td>`;
      }
      ll1Html += '</tr>';
    }
    ll1Html += '</tbody></table>';
    document.getElementById('ll1-table-container').innerHTML = ll1Html;

    // 3. SLR(1) Table & Items
    try {
      const slr1 = app.cfgEngine.buildSLR1Table();
      const slrBanner = document.getElementById('slr1-status-banner');
      if (slr1.isSLR1) {
        slrBanner.className = 'status-callout success';
        slrBanner.textContent = `✓ Grammar is SLR(1)! Generated ${slr1.states.length} LR(0) states without conflicts.`;
      } else {
        slrBanner.className = 'status-callout warning';
        slrBanner.textContent = `✗ Conflicts detected in SLR(1) table: ${slr1.conflicts.join('; ')}`;
      }

      // Render Items
      const itemsContainer = document.getElementById('slr1-items-container');
      itemsContainer.innerHTML = slr1.states.map((st, idx) => `
        <div style="margin-bottom:8px;">
          <strong>State I${idx}:</strong><br>
          ${st.map(it => `&bull; ${slr1.itemToString(it)}`).join('<br>')}
        </div>
      `).join('');

      // Render SLR(1) ACTION/GOTO Table
      let slrHtml = '<table class="clean-table"><thead><tr><th rowspan="2">State</th><th colspan="' + terminalsWithEnd.length + '">ACTION</th>';
      slrHtml += '<th colspan="' + app.cfgEngine.nonTerminals.size + '">GOTO</th></tr><tr>';

      for (const t of terminalsWithEnd) slrHtml += `<th>${t}</th>`;
      for (const nt of app.cfgEngine.nonTerminals) slrHtml += `<th>${nt}</th>`;
      slrHtml += '</tr></thead><tbody>';

      for (let i = 0; i < slr1.states.length; i++) {
        slrHtml += `<tr><td class="state-name">I${i}</td>`;
        for (const t of terminalsWithEnd) {
          const act = slr1.actionTable[i][t] || '';
          slrHtml += `<td>${act}</td>`;
        }
        for (const nt of app.cfgEngine.nonTerminals) {
          const gotoSt = slr1.gotoTable[i][nt] !== undefined ? slr1.gotoTable[i][nt] : '';
          slrHtml += `<td>${gotoSt}</td>`;
        }
        slrHtml += '</tr>';
      }
      slrHtml += '</tbody></table>';
      document.getElementById('slr1-table-container').innerHTML = slrHtml;
    } catch (e) {
      console.warn('SLR(1) error', e);
    }
  }

  // ===================================================================
  // 8. TURING MACHINES (TAB 6)
  // ===================================================================
  function initTM() {
    const canvasEl = document.getElementById('tm-canvas');
    app.tmCanvas = new AutomataCanvas(canvasEl, app.tmAutomaton, {
      onModelChange: () => {
        updateTmInfo();
        app.tmEngine.reset();
      },
      onAddTransitionPrompt: (from, to) => openEditTransitionModal(from, to, null, false, 'TM'),
      onStateDoubleClick: (state) => openEditStateModal(state),
      onTransitionDoubleClick: (trans) => {
        const from = app.tmAutomaton.getState(trans.from);
        const to = app.tmAutomaton.getState(trans.to);
        openEditTransitionModal(from, to, trans, false, 'TM');
      }
    });

    app.tmEngine = new TuringMachineEngine(app.tmAutomaton, 1);

    // Tape Count Toggle
    document.querySelectorAll('input[name="tm-tape-count"]').forEach(radio => {
      radio.addEventListener('change', () => {
        const count = parseInt(radio.value, 10);
        app.tmEngine.setTapeCount(count);
        document.getElementById('tape2-ribbon-card').style.display = count === 2 ? 'block' : 'none';
        resetTM();
      });
    });

    // Sim Controls
    document.getElementById('btn-tm-step').addEventListener('click', () => {
      pauseTM();
      stepTM();
    });

    document.getElementById('btn-tm-run').addEventListener('click', () => {
      playTM();
    });

    document.getElementById('btn-tm-pause').addEventListener('click', () => {
      pauseTM();
    });

    document.getElementById('btn-tm-reset').addEventListener('click', () => {
      resetTM();
    });

    const speedSlider = document.getElementById('tm-speed');
    speedSlider.addEventListener('input', () => {
      app.tmSimSpeed = parseInt(speedSlider.value, 10);
      document.getElementById('tm-speed-label').textContent = `${app.tmSimSpeed}ms`;
      if (app.tmSimTimer) {
        clearInterval(app.tmSimTimer);
        app.tmSimTimer = setInterval(stepTM, app.tmSimSpeed);
      }
    });

    // Presets
    document.getElementById('btn-tm-preset-inc').addEventListener('click', () => loadPreset('tm', 'binary_inc'));
    document.getElementById('btn-tm-preset-palin').addEventListener('click', () => loadPreset('tm', 'palindrome'));
    document.getElementById('btn-tm-preset-anbncn').addEventListener('click', () => loadPreset('tm', 'anbncn'));

    loadPreset('tm', 'binary_inc');
  }

  function playTM() {
    document.getElementById('btn-tm-run').classList.add('hidden');
    document.getElementById('btn-tm-pause').classList.remove('hidden');

    const statusBadge = document.getElementById('tm-status-badge');
    statusBadge.className = 'sim-status running';
    statusBadge.querySelector('.status-text').textContent = 'Running...';

    if (app.tmSimTimer) clearInterval(app.tmSimTimer);
    app.tmSimTimer = setInterval(() => {
      const res = stepTM();
      if (!res || res.halted) {
        pauseTM();
      }
    }, app.tmSimSpeed);
  }

  function pauseTM() {
    if (app.tmSimTimer) {
      clearInterval(app.tmSimTimer);
      app.tmSimTimer = null;
    }
    document.getElementById('btn-tm-pause').classList.add('hidden');
    document.getElementById('btn-tm-run').classList.remove('hidden');
  }

  function resetTM() {
    pauseTM();
    const str = document.getElementById('tm-input-string').value;
    app.tmEngine.setInput(str);
    app.tmCanvas.setActiveStates(app.tmEngine.currentState ? [app.tmEngine.currentState.id] : []);
    app.tmCanvas.setActiveTransitions([]);

    renderTmTape();
    updateTmInfo();

    const statusBadge = document.getElementById('tm-status-badge');
    statusBadge.className = 'sim-status idle';
    statusBadge.querySelector('.status-text').textContent = 'Ready';

    document.getElementById('tm-trace-log').innerHTML = '<div class="trace-entry info">Turing Machine reset. Ready.</div>';
  }

  function stepTM() {
    const res = app.tmEngine.step();
    if (!res) return null;

    if (res.currentState) {
      app.tmCanvas.setActiveStates([res.currentState.id]);
    }

    renderTmTape();
    updateTmInfo();

    const traceLog = document.getElementById('tm-trace-log');
    const lastHistory = app.tmEngine.history[app.tmEngine.history.length - 1];
    if (lastHistory) {
      const entry = document.createElement('div');
      entry.className = `trace-entry ${res.halted ? (res.accepted ? 'accept' : 'reject') : 'step'}`;
      entry.innerHTML = `Step ${lastHistory.step} [${lastHistory.state}] &bull; ${lastHistory.desc}`;
      traceLog.appendChild(entry);
      traceLog.scrollTop = traceLog.scrollHeight;
    }

    if (res.halted) {
      const statusBadge = document.getElementById('tm-status-badge');
      if (res.accepted) {
        statusBadge.className = 'sim-status accepted';
        statusBadge.querySelector('.status-text').textContent = 'HALTED (ACCEPT) ✓';
      } else {
        statusBadge.className = 'sim-status rejected';
        statusBadge.querySelector('.status-text').textContent = 'HALTED (REJECT) ✗';
      }
    }

    return res;
  }

  function renderTmTape() {
    // Tape 1
    const strip1 = document.getElementById('tape1-strip');
    const cells1 = app.tmEngine.getTapeWindow(0, 9);
    strip1.innerHTML = '';

    cells1.forEach(c => {
      const cellDiv = document.createElement('div');
      cellDiv.className = `tape-cell ${c.isHead ? 'active-head' : ''} ${c.symbol === '⊔' ? 'blank' : ''}`;
      cellDiv.textContent = c.symbol;
      strip1.appendChild(cellDiv);
    });

    document.getElementById('tape1-head-pos').textContent = `Head Index: ${app.tmEngine.headPositions[0]}`;

    // Tape 2
    if (app.tmEngine.tapeCount === 2) {
      const strip2 = document.getElementById('tape2-strip');
      const cells2 = app.tmEngine.getTapeWindow(1, 9);
      strip2.innerHTML = '';

      cells2.forEach(c => {
        const cellDiv = document.createElement('div');
        cellDiv.className = `tape-cell ${c.isHead ? 'active-head' : ''} ${c.symbol === '⊔' ? 'blank' : ''}`;
        cellDiv.textContent = c.symbol;
        strip2.appendChild(cellDiv);
      });

      document.getElementById('tape2-head-pos').textContent = `Head Index: ${app.tmEngine.headPositions[1]}`;
    }
  }

  function updateTmInfo() {
    document.getElementById('tm-step-count').textContent = app.tmEngine.stepCount;
    document.getElementById('tm-current-state-badge').textContent = `State: ${app.tmEngine.currentState?.name || '?'}`;
    document.getElementById('tm-transitions-table').innerHTML = app.tmEngine.generateTransitionsTable();
  }

  // ===================================================================
  // 9. PUMPING LEMMA LAB (TAB 7)
  // ===================================================================
  function initPumpingLemma() {
    const lab = app.pumpingLab;

    const btnReg = document.getElementById('btn-pumping-reg');
    const btnCfl = document.getElementById('btn-pumping-cfl');
    const langSelect = document.getElementById('pumping-language-select');
    const pInput = document.getElementById('pumping-p-val');
    const sInput = document.getElementById('pumping-string-s');
    const splitSelect = document.getElementById('pumping-split-select');
    const iInput = document.getElementById('pumping-i-val');

    function populateLanguages() {
      langSelect.innerHTML = '';
      lab.getCurrentLanguages().forEach(l => {
        const opt = document.createElement('option');
        opt.value = l.id;
        opt.textContent = l.name;
        langSelect.appendChild(opt);
      });
      langSelect.value = lab.selectedLanguageId;
      updateLanguageInfo();
    }

    function updateLanguageInfo() {
      const curLang = lab.getCurrentLanguage();
      document.getElementById('pumping-lang-desc').textContent = curLang.description;
      sInput.value = curLang.sampleString(lab.p);
      generateSplits();
    }

    function generateSplits() {
      const s = sInput.value;
      const p = parseInt(pInput.value, 10);
      lab.validSplits = lab.generateRegularSplits(s, p);

      splitSelect.innerHTML = '';
      lab.validSplits.forEach((sp, idx) => {
        const opt = document.createElement('option');
        opt.value = idx;
        opt.textContent = sp.label;
        splitSelect.appendChild(opt);
      });

      renderSplitVisual();
    }

    function renderSplitVisual() {
      const idx = parseInt(splitSelect.value, 10) || 0;
      const sp = lab.validSplits[idx];
      const box = document.getElementById('pumping-split-visual');

      if (!sp) {
        box.innerHTML = '';
        return;
      }

      box.innerHTML = `
        <span class="split-chunk chunk-x">x: "${sp.x || 'ε'}"</span>
        <span class="split-chunk chunk-y">y (Pumped): "${sp.y}"</span>
        <span class="split-chunk chunk-z">z: "${sp.z}"</span>
      `;
    }

    btnReg.addEventListener('click', () => {
      btnReg.className = 'btn btn-xs btn-primary active';
      btnCfl.className = 'btn btn-xs btn-secondary';
      lab.currentMode = 'regular';
      lab.selectedLanguageId = 'anbn';
      document.getElementById('lemma-theorem-text').innerHTML = `
        <strong>Pumping Lemma for Regular Languages:</strong> Any regular language has pumping length $p$ such that every $s \\in L$ with $|s| \\ge p$ can be written $s = xyz$ where $|xy| \\le p$, $|y| \\ge 1$, and $\\forall i \\ge 0, xy^i z \\in L$.
      `;
      populateLanguages();
    });

    btnCfl.addEventListener('click', () => {
      btnCfl.className = 'btn btn-xs btn-primary active';
      btnReg.className = 'btn btn-xs btn-secondary';
      lab.currentMode = 'cfl';
      lab.selectedLanguageId = 'anbncn';
      document.getElementById('lemma-theorem-text').innerHTML = `
        <strong>Pumping Lemma for Context-Free Languages:</strong> Any context-free language has pumping length $p$ such that every $s \\in L$ with $|s| \\ge p$ can be written $s = uvwxy$ where $|vwx| \\le p$, $|vx| \\ge 1$, and $\\forall i \\ge 0, uv^i wx^i y \\in L$.
      `;
      populateLanguages();
    });

    langSelect.addEventListener('change', () => {
      lab.selectedLanguageId = langSelect.value;
      updateLanguageInfo();
    });

    document.getElementById('btn-confirm-p').addEventListener('click', () => {
      lab.p = parseInt(pInput.value, 10);
      updateLanguageInfo();
      ExportUtils.showToast(`Pumping length set to p = ${lab.p}`, 'info');
    });

    document.getElementById('btn-confirm-s').addEventListener('click', () => {
      generateSplits();
      ExportUtils.showToast('String s selected.', 'info');
    });

    splitSelect.addEventListener('change', () => {
      renderSplitVisual();
    });

    document.getElementById('btn-test-pump').addEventListener('click', () => {
      const idx = parseInt(splitSelect.value, 10) || 0;
      const sp = lab.validSplits[idx];
      const i = parseInt(iInput.value, 10);
      const curLang = lab.getCurrentLanguage();

      if (!sp) return;

      const pumpedStr = lab.pumpString(sp, i);
      const inLang = curLang.isInLanguage(pumpedStr);

      const verdictBox = document.getElementById('pumping-verdict-box');

      if (!inLang) {
        verdictBox.innerHTML = `
          <div class="status-callout success" style="font-size:0.9rem;">
            <strong>CONTRADICTION FOUND! (Proof Succeeded) ✓</strong>
            <br>Pumped string $s' = xy^{${i}}z$ is: <code>"${pumpedStr}"</code>
            <br><strong>Reason:</strong> ${curLang.violationReason(pumpedStr)}
            <br>Since $xy^{${i}}z \\notin L$, the Pumping Lemma condition fails! Therefore, $L$ is <strong>NOT REGULAR</strong>!
          </div>
        `;
      } else {
        verdictBox.innerHTML = `
          <div class="status-callout warning">
            Pumped string $s' = xy^{${i}}z = "${pumpedStr}"$ happens to still be in $L$.
            <br>Try pumping with a different exponent $i$ (e.g. $i=0$ to pump down or $i=2$) or pick another split!
          </div>
        `;
      }
    });

    populateLanguages();
  }

  // ===================================================================
  // 10. L-SYSTEMS (TAB 8)
  // ===================================================================
  function initLSystems() {
    const canvas = document.getElementById('lsystem-canvas');
    app.lsystemEngine = new LSystemEngine(canvas);

    const axiomInput = document.getElementById('lsys-axiom');
    const rulesInput = document.getElementById('lsys-rules');
    const angleInput = document.getElementById('lsys-angle');
    const iterInput = document.getElementById('lsys-iterations');

    function renderLSystem() {
      const axiom = axiomInput.value.trim();
      const angle = parseFloat(angleInput.value) || 60;
      const iterations = parseInt(iterInput.value, 10) || 3;

      const rules = {};
      const lines = rulesInput.value.split('\n').map(l => l.trim()).filter(Boolean);
      for (const line of lines) {
        const parts = line.split('->').map(p => p.trim());
        if (parts.length === 2) {
          rules[parts[0]] = parts[1];
        }
      }

      const str = app.lsystemEngine.render(axiom, rules, angle, iterations);
      document.getElementById('lsys-string-output').textContent = str.slice(0, 500) + (str.length > 500 ? '...' : '');
      document.getElementById('lsys-length-badge').textContent = `Length: ${str.length}`;
    }

    document.getElementById('btn-render-lsystem').addEventListener('click', renderLSystem);
    document.getElementById('btn-step-lsystem').addEventListener('click', () => {
      iterInput.value = Math.min(parseInt(iterInput.value, 10) + 1, 6);
      renderLSystem();
    });

    document.querySelectorAll('.chip-btn[data-lsystem]').forEach(btn => {
      btn.addEventListener('click', () => {
        const pKey = btn.dataset.lsystem;
        const p = app.lsystemEngine.presets[pKey];
        if (p) {
          axiomInput.value = p.axiom;
          rulesInput.value = Object.entries(p.rules).map(([k, v]) => `${k} -> ${v}`).join('\n');
          angleInput.value = p.angle;
          iterInput.value = p.iterations;
          renderLSystem();
        }
      });
    });

    renderLSystem();
  }

  // ===================================================================
  // 11. MODAL DIALOGS (STATE & TRANSITION EDITORS)
  // ===================================================================
  const modal = document.getElementById('edit-modal');
  const modalTitle = document.getElementById('modal-title');
  const modalBody = document.getElementById('modal-body-content');
  const modalSave = document.getElementById('modal-btn-save');
  const modalCancel = document.getElementById('modal-btn-cancel');
  const modalClose = document.getElementById('modal-close');

  function closeModal() {
    modal.classList.add('hidden');
    modalSave.onclick = null;
  }

  modalCancel.addEventListener('click', closeModal);
  modalClose.addEventListener('click', closeModal);

  function openEditStateModal(state, isMoore = false) {
    modalTitle.textContent = `Edit State: ${state.name}`;
    modalBody.innerHTML = `
      <div style="display:flex; flex-direction:column; gap:12px;">
        <div>
          <label style="display:block; font-size:0.8rem; margin-bottom:4px;">State Name:</label>
          <input type="text" id="edit-state-name" class="code-input" value="${state.name}" style="width:100%;" />
        </div>
        ${isMoore ? `
          <div>
            <label style="display:block; font-size:0.8rem; margin-bottom:4px;">Moore State Output Symbol:</label>
            <input type="text" id="edit-state-output" class="code-input" value="${state.output || ''}" style="width:100%;" />
          </div>
        ` : ''}
        <div style="display:flex; gap:16px;">
          <label style="font-size:0.85rem;"><input type="checkbox" id="edit-state-initial" ${state.isInitial ? 'checked' : ''} /> Initial State (▶)</label>
          <label style="font-size:0.85rem;"><input type="checkbox" id="edit-state-final" ${state.isFinal ? 'checked' : ''} /> Final / Accept State (◎)</label>
        </div>
      </div>
    `;

    modal.classList.remove('hidden');

    modalSave.onclick = () => {
      const newName = document.getElementById('edit-state-name').value.trim();
      if (newName) state.name = newName;

      if (isMoore) {
        state.output = document.getElementById('edit-state-output').value.trim();
      }

      state.isInitial = document.getElementById('edit-state-initial').checked;
      state.isFinal = document.getElementById('edit-state-final').checked;

      closeModal();
      if (app.activeTab === 'tab-fa') {
        app.faCanvas.render();
        updateFAInfo();
      } else if (app.activeTab === 'tab-transducers') {
        app.transCanvas.render();
        updateTransducerUI();
      } else if (app.activeTab === 'tab-pda') {
        app.pdaCanvas.render();
        updatePdaTransitionsTable();
      } else if (app.activeTab === 'tab-tm') {
        app.tmCanvas.render();
        updateTmInfo();
      }
    };
  }

  function openEditTransitionModal(fromState, toState, existingTrans = null, isMealy = false, customModelType = null) {
    modalTitle.textContent = existingTrans
      ? `Edit Transition: ${fromState.name} &rarr; ${toState.name}`
      : `Add Transition: ${fromState.name} &rarr; ${toState.name}`;

    let defaultSyms = existingTrans ? existingTrans.symbols.join(', ') : '0';
    let hint = "Enter comma-separated symbols (e.g. '0, 1', use 'ε' for epsilon)";

    if (isMealy) {
      hint = "Format: 'in/out' (e.g. '0/1, 1/0')";
      if (!existingTrans) defaultSyms = '0/1';
    } else if (customModelType === 'PDA') {
      hint = "Format: 'input, pop -> push' (e.g. 'a, Z0 -> AZ0' or 'b, A -> ε')";
      if (!existingTrans) defaultSyms = 'a, Z0 -> AZ0';
    } else if (customModelType === 'TM') {
      hint = "Format: 'read -> write, Move' (e.g. '0 -> 1, R' or '_ -> _, L')";
      if (!existingTrans) defaultSyms = '0 -> 1, R';
    }

    modalBody.innerHTML = `
      <div style="display:flex; flex-direction:column; gap:12px;">
        <div>
          <label style="display:block; font-size:0.8rem; margin-bottom:4px;">Transition Symbol(s):</label>
          <input type="text" id="edit-trans-syms" class="code-input" value="${defaultSyms}" style="width:100%;" />
          <span style="font-size:0.75rem; color:var(--text-muted);">${hint}</span>
        </div>
        <div>
          <label style="display:block; font-size:0.8rem; margin-bottom:4px;">Curve Curvature Offset:</label>
          <input type="range" id="edit-trans-curve" min="-80" max="80" value="${existingTrans ? existingTrans.curve : 0}" style="width:100%;" />
        </div>
      </div>
    `;

    modal.classList.remove('hidden');

    modalSave.onclick = () => {
      const symText = document.getElementById('edit-trans-syms').value.trim();
      const curveVal = parseInt(document.getElementById('edit-trans-curve').value, 10);

      if (symText) {
        let symArray = [];
        if (customModelType === 'PDA' || customModelType === 'TM') {
          symArray = [symText];
        } else {
          symArray = symText.split(',').map(s => s.trim()).filter(Boolean);
        }

        let targetAut = app.faAutomaton;
        let targetCanvas = app.faCanvas;

        if (app.activeTab === 'tab-transducers') {
          targetAut = app.transAutomaton;
          targetCanvas = app.transCanvas;
        } else if (app.activeTab === 'tab-pda') {
          targetAut = app.pdaAutomaton;
          targetCanvas = app.pdaCanvas;
        } else if (app.activeTab === 'tab-tm') {
          targetAut = app.tmAutomaton;
          targetCanvas = app.tmCanvas;
        }

        if (existingTrans) {
          existingTrans.symbols = symArray;
          existingTrans.curve = curveVal;
        } else {
          targetAut.addTransition(fromState.id, toState.id, symArray, curveVal);
        }

        targetCanvas.render();
        if (app.activeTab === 'tab-fa') updateFAInfo();
        else if (app.activeTab === 'tab-transducers') updateTransducerUI();
        else if (app.activeTab === 'tab-pda') updatePdaTransitionsTable();
        else if (app.activeTab === 'tab-tm') updateTmInfo();
      }

      closeModal();
    };
  }

  // ===================================================================
  // 12. INITIALIZATION ORCHESTRATION
  // ===================================================================
  initTheme();
  initTabs();
  initPresetsMenu();
  initHeaderButtons();

  initFA();
  initConversions();
  initTransducers();
  initPDA();
  initCFG();
  initTM();
  initPumpingLemma();
  initLSystems();

  console.log('Theory of Computation Studio initialized. Developed by Gururaj Surampalli.');
});
