/**
 * Theory of Computation Studio — JFLAP Web Edition
 * Developed by Gururaj Surampalli
 * Model Data Structures: State, Transition, and Automaton
 */

class State {
  constructor(id, name, x, y, isInitial = false, isFinal = false, output = '') {
    this.id = id;
    this.name = name || `q${id}`;
    this.x = x;
    this.y = y;
    this.isInitial = isInitial;
    this.isFinal = isFinal;
    this.output = output; // Used for Moore machines
    this.radius = 26;
  }

  clone() {
    return new State(this.id, this.name, this.x, this.y, this.isInitial, this.isFinal, this.output);
  }
}

class Transition {
  constructor(id, fromId, toId, symbols = ['0'], curve = 0) {
    this.id = id;
    this.from = fromId;
    this.to = toId;
    // symbols is array of strings e.g. ['0', '1'] or ['ε'] or ['0/1'] (Mealy) or ['a, Z0 -> AZ0'] (PDA)
    this.symbols = Array.isArray(symbols) ? [...symbols] : [symbols];
    this.curve = curve; // 0 for straight line, positive/negative for curved Bézier arcs
  }

  getLabel() {
    return this.symbols.join(', ');
  }

  clone() {
    return new Transition(this.id, this.from, this.to, [...this.symbols], this.curve);
  }
}

class Automaton {
  constructor(type = 'FA') {
    this.type = type; // 'FA' | 'MEALY' | 'MOORE' | 'PDA' | 'TM'
    this.states = new Map();
    this.transitions = [];
    this.nextStateId = 0;
    this.nextTransId = 0;
  }

  addState(name = null, x = 100, y = 100, isInitial = false, isFinal = false, output = '') {
    const id = this.nextStateId++;
    const stateName = name || `q${id}`;
    // If setting as initial and it's the only one, or clearing others if single initial
    if (isInitial) {
      for (const s of this.states.values()) {
        s.isInitial = false;
      }
    }
    const state = new State(id, stateName, x, y, isInitial, isFinal, output);
    this.states.set(id, state);
    return state;
  }

  removeState(id) {
    if (!this.states.has(id)) return false;
    this.states.delete(id);
    // Remove all associated transitions
    this.transitions = this.transitions.filter(t => t.from !== id && t.to !== id);
    return true;
  }

  getState(id) {
    return this.states.get(id);
  }

  getStateByName(name) {
    for (const s of this.states.values()) {
      if (s.name === name) return s;
    }
    return null;
  }

  getInitialState() {
    for (const s of this.states.values()) {
      if (s.isInitial) return s;
    }
    return null;
  }

  getFinalStates() {
    return Array.from(this.states.values()).filter(s => s.isFinal);
  }

  setInitialState(id) {
    for (const s of this.states.values()) {
      s.isInitial = (s.id === id);
    }
  }

  toggleFinalState(id) {
    const s = this.states.get(id);
    if (s) {
      s.isFinal = !s.isFinal;
      return s.isFinal;
    }
    return false;
  }

  addTransition(fromId, toId, symbols = ['0'], curve = 0) {
    if (!this.states.has(fromId) || !this.states.has(toId)) return null;

    // Check if transition between these two already exists
    const existing = this.transitions.find(t => t.from === fromId && t.to === toId);
    if (existing) {
      const symList = Array.isArray(symbols) ? symbols : [symbols];
      for (const sym of symList) {
        if (!existing.symbols.includes(sym)) {
          existing.symbols.push(sym);
        }
      }
      return existing;
    }

    // Auto-compute curve if reverse transition exists
    let finalCurve = curve;
    if (fromId === toId) {
      finalCurve = 0; // Self loop handled specially in renderer
    } else {
      const reverse = this.transitions.find(t => t.from === toId && t.to === fromId);
      if (reverse && curve === 0) {
        finalCurve = 35; // Curve out to avoid overlap
        if (reverse.curve === 0) {
          reverse.curve = 35;
        }
      }
    }

    const trans = new Transition(this.nextTransId++, fromId, toId, symbols, finalCurve);
    this.transitions.push(trans);
    return trans;
  }

  removeTransition(id) {
    const idx = this.transitions.findIndex(t => t.id === id);
    if (idx !== -1) {
      this.transitions.splice(idx, 1);
      return true;
    }
    return false;
  }

  getTransitionsFrom(fromId) {
    return this.transitions.filter(t => t.from === fromId);
  }

  getAlphabet() {
    const set = new Set();
    for (const t of this.transitions) {
      for (const s of t.symbols) {
        if (s !== 'ε' && s !== 'e' && s !== 'λ') {
          // If Mealy machine with 'a/0', split
          if (s.includes('/')) {
            const sym = s.split('/')[0].trim();
            if (sym && sym !== 'ε') set.add(sym);
          } else if (s.includes(',')) {
            // PDA format: 'a, Z0 -> AZ0'
            const sym = s.split(',')[0].trim();
            if (sym && sym !== 'ε') set.add(sym);
          } else if (s.includes('->')) {
            // TM format: '0 -> 1, R'
            const sym = s.split('->')[0].trim();
            if (sym && sym !== '⊔' && sym !== '_') set.add(sym);
          } else {
            set.add(s.trim());
          }
        }
      }
    }
    return Array.from(set).sort();
  }

  isDFA() {
    // Check if initial state exists
    if (!this.getInitialState()) return false;
    const alphabet = this.getAlphabet();

    // In a DFA, for each state and each symbol in Σ, there must be exactly 1 transition
    for (const state of this.states.values()) {
      const transitions = this.getTransitionsFrom(state.id);
      const symbolCount = {};

      for (const t of transitions) {
        for (const sym of t.symbols) {
          if (sym === 'ε' || sym === 'e' || sym === 'λ') {
            return false; // ε-transitions not allowed in DFA
          }
          symbolCount[sym] = (symbolCount[sym] || 0) + 1;
        }
      }

      // Check for non-determinism (more than 1 transition per symbol)
      for (const sym of alphabet) {
        if ((symbolCount[sym] || 0) > 1) {
          return false;
        }
      }
    }
    return true;
  }

  clear() {
    this.states.clear();
    this.transitions = [];
    this.nextStateId = 0;
    this.nextTransId = 0;
  }

  clone() {
    const copy = new Automaton(this.type);
    copy.nextStateId = this.nextStateId;
    copy.nextTransId = this.nextTransId;
    for (const s of this.states.values()) {
      copy.states.set(s.id, s.clone());
    }
    copy.transitions = this.transitions.map(t => t.clone());
    return copy;
  }

  toJSON() {
    return {
      version: '1.0',
      title: 'Theory of Computation Automaton',
      author: 'Gururaj Surampalli',
      type: this.type,
      states: Array.from(this.states.values()).map(s => ({
        id: s.id,
        name: s.name,
        x: s.x,
        y: s.y,
        isInitial: s.isInitial,
        isFinal: s.isFinal,
        output: s.output
      })),
      transitions: this.transitions.map(t => ({
        id: t.id,
        from: t.from,
        to: t.to,
        symbols: t.symbols,
        curve: t.curve
      }))
    };
  }

  fromJSON(data) {
    this.clear();
    if (data.type) this.type = data.type;
    let maxStateId = 0;
    let maxTransId = 0;

    if (data.states && Array.isArray(data.states)) {
      for (const s of data.states) {
        const state = new State(s.id, s.name, s.x, s.y, !!s.isInitial, !!s.isFinal, s.output || '');
        this.states.set(s.id, state);
        if (s.id >= maxStateId) maxStateId = s.id + 1;
      }
    }

    if (data.transitions && Array.isArray(data.transitions)) {
      for (const t of data.transitions) {
        const trans = new Transition(t.id, t.from, t.to, t.symbols, t.curve || 0);
        this.transitions.push(trans);
        if (t.id >= maxTransId) maxTransId = t.id + 1;
      }
    }

    this.nextStateId = maxStateId;
    this.nextTransId = maxTransId;
  }
}
